﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Models.Dictionaries;

namespace SystemHR.DataAccessLayer.ViewModels
{
    public class DepartamentViewModel : EntityModel
    {
        public string Name { get; set; }
        public Employee Manager { get; set; }
        public string Location { get; set; }
        public Departament ParentDepartament { get; set; }
    }
}
