﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SystemHR.DataAccessLayer.Models;

namespace SystemHR.DataAccessLayer.Classes
{
    public class PositionEventArgs : EventArgs
    {
        public PositionModel position { private set; get; }

        public PositionEventArgs(PositionModel position)
        {
            this.position = position;
        }
    }
}
