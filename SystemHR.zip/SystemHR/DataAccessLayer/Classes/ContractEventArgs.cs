﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SystemHR.DataAccessLayer.Models;

namespace SystemHR.DataAccessLayer.Classes
{
    public class ContractEventArgs : EventArgs
    {
        public ContractModel contract { private set; get; }
        public ContractEventArgs(ContractModel contract)
        {
            this.contract = contract;
        }
    }
}
