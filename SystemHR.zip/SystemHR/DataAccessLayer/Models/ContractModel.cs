﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SystemHR.DataAccessLayer.Models.Dictionaries;

namespace SystemHR.DataAccessLayer.Models
{
    public class ContractModel : EntityModel
    {
        public TypeContract TypeContract { get; set; }

        public DateTime? ConclusionDate { get; set; }

        public DateTime? DateFrom { get; set; }

        public DateTime? DateTo { get; set; }

        public Position Position { get; set; }

        public Departament Departament { get; set; }

        public decimal Salary { get; set; }

        public Currency Currency { get; set; }

        public TypeRate TypeRate { get; set; }

        public TerminationWay TerminationWay { get; set; }

        public string LastName { get; set; }

        public string FirstName { get; set; }
        public int Code { get; set; }
    }
}
