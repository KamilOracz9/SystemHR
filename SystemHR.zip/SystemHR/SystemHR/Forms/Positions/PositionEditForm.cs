﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.UserInterface.Forms.Base;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Classes;
using System.Data.SqlClient;

namespace SystemHR.UserInterface.Forms.Positions
{
    public partial class PositionEditForm : BaseForm
    {
        #region fields
        public static PositionsForm positionTable = (PositionsForm)Application.OpenForms["PositionsForm"];
        #endregion
        #region constructors
        public PositionEditForm()
        {
            InitializeComponent();
            LoadData();
            ValidationControls();
        }
        #endregion
        #region private methods
        private void LoadData()
        {
            SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
            SqlCommand showPosition = new SqlCommand("select * from PositionModel where Name=@Name",con);
            SqlDataReader dataReader = null;
            con.Open();
            showPosition.Parameters.AddWithValue("@Name",positionTable.GetName());
            dataReader = showPosition.ExecuteReader();
            while(dataReader.Read())
            {
                txtName.Text = (dataReader["Name"].ToString());
                nudMaxSalary.Value = decimal.Parse(dataReader["MaxSalary"].ToString());
                nudMinSalary.Value = decimal.Parse(dataReader["MinSalary"].ToString());
                lblPosition.Text = $"{(dataReader["Name"].ToString())}";
            }
            con.Close();
        }
        private bool ValidationForm()
        {
            StringBuilder sbErrorMessage = new StringBuilder();
            string nameErrorMessage = epName.GetError(txtName);
            if (!string.IsNullOrEmpty(nameErrorMessage))
            {
                sbErrorMessage.Append(nameErrorMessage);
            }
            if (sbErrorMessage.Length > 0)
            {
                MessageBox.Show(
                    sbErrorMessage.ToString(),
                    "Modyfikuj stanowisko",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            ValidationControls();
        }
        #endregion
        #region events
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidationForm())
            {
                SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
                SqlCommand updatePositions = new SqlCommand("update PositionModel set Name=@Name,MaxSalary=@MaxSalary,MinSalary=@MinSalary where Name = @LastUsingName", con);
                con.Open();
                updatePositions.Parameters.AddWithValue("@LastUsingName", positionTable.GetName());
                updatePositions.Parameters.AddWithValue("@Name",txtName.Text);
                updatePositions.Parameters.AddWithValue("@MaxSalary", nudMaxSalary.Value);
                updatePositions.Parameters.AddWithValue("@MinSalary", nudMinSalary.Value);
                updatePositions.ExecuteNonQuery();
                con.Close();
            }
            Close();
            positionTable.LoadData();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void ValidationControls()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                epName.SetError(txtName, "Pole nazwa jest wymagane");
            }
            else epName.Clear();
        }
        #endregion 
    }
}
