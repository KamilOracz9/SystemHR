﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Classes;
using System.Data.SqlClient;

namespace SystemHR.UserInterface.Forms.Positions
{
    public partial class PositionsForm : Form
    {
        #region fields
        public static bool tabIsOpen = false;
        #endregion
        #region constructors
        public PositionsForm()
        {
            InitializeComponent();
            LoadData();
        }
        #endregion
        #region private methods
        private void PositionsForm_Load(object sender, EventArgs e)
        {
            // TODO: Ten wiersz kodu wczytuje dane do tabeli 'systemHRDataSet11.PositionViewModel' . Możesz go przenieść lub usunąć.
            this.taPositions.Fill(this.dsPositions.PositionViewModel);
        }
        #endregion
        #region events
        private void btnCreate_Click(object sender, EventArgs e)
        {
            PositionAddForm frm = new PositionAddForm();
            frm.ShowDialog();
        }
        private void btnModify_Click(object sender, EventArgs e)
        {
            if (dgvPositions.Rows.Count > 0)
            {
                PositionEditForm frm = new PositionEditForm();
                frm.ShowDialog();
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            dgvPositions.Refresh();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (dgvPositions.Rows.Count > 0)
            {
                SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
                SqlCommand removePosition = new SqlCommand("delete from PositionModel where Name=@Name",con);
                con.Open();
                removePosition.Parameters.AddWithValue("@Name",GetName());
                removePosition.ExecuteNonQuery();
                con.Close();
                LoadData();
            }
        }
        #endregion
        #region public methods
        public string GetName()
        {
            string colValue = dgvPositions.CurrentRow.Cells["colName"].Value.ToString();
            return colValue;
        }
        public void LoadData()
        {
            SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
            SqlCommand loadData = new SqlCommand("select * from PositionViewModel", con);
            con.Open();
            SqlDataAdapter dataAdapter = new SqlDataAdapter(loadData);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            bsPositions.DataSource = dataTable;
            dgvPositions.DataSource = bsPositions;
            con.Close();
        }
        #endregion
    }
}