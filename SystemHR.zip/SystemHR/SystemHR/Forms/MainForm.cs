﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using SystemHR.DataAccessLayer.Models;
using SystemHR.UserInterface.Forms.Contracts;
using SystemHR.UserInterface.Forms.Departaments;
using SystemHR.UserInterface.Forms.Employees;
using SystemHR.UserInterface.Forms.OrganizationStructure;
using SystemHR.UserInterface.Forms.Positions;
using SystemHR.UserInterface.Forms.Salaries;

namespace SystemHR.UserInterface.Forms
{
    public partial class tcMain : Form
    {
        #region fields
        Connection connection = new Connection();
        #endregion
        #region constructors
        public tcMain()
        {
            InitializeComponent();
            GetConnection();
            DataBaseConnection(connection);
        }
        #endregion
        #region private methods
        private Connection GetConnection()
        {
            Connection connection = new Connection()
            {
                ServerName = @"localhost\SQLEXPRESS",
                DataBaseName = "SystemHR",
                UserName = string.Empty,
                Password = string.Empty
            };
            return connection;
        }

        private void DataBaseConnection(Connection connection)
        {
            string connetionString = null;
            string ServerName = connection.ServerName;
            string DataBaseName = connection.DataBaseName;
            string UserName = connection.UserName;
            string Password = connection.Password;
            SqlConnection cnn;
            connetionString = @"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;";
            cnn = new SqlConnection(connetionString);
            try
            {
                cnn.Open();
                MessageBox.Show("Połączono pomyślnie!");
                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nie można się połączyć!");
                Close();
            }
        }
        private void btnEmployees_Click(object sender, EventArgs e)
        {
            if (EmployeesForm.tabIsOpen == false)
            {
                EmployeesForm frm = new EmployeesForm();
                ShowTab("Pracownicy", frm);
                EmployeesForm.tabIsOpen = true;
            }
        }
        private void btnContracts_Click(object sender, EventArgs e)
        {
            if (ContractsForm.tabIsOpen == false)
            {
                ContractsForm frm = new ContractsForm();
                ShowTab("Umowy", frm);
                ContractsForm.tabIsOpen = true;
            }
        }
        private void btnOrganicationStructure_Click(object sender, EventArgs e)
        {
            if (OrganizationStructureForm.tabIsOpen == false)
            {
                OrganizationStructureForm frm = new OrganizationStructureForm();
                ShowTab("Struktury organizacyjne", frm);
                OrganizationStructureForm.tabIsOpen = true;
            }
        }

        private void btnSalaries_Click(object sender, EventArgs e)
        {
            if (SalariesForm.tabIsOpen == false)
            {
                SalariesForm frm = new SalariesForm();
                ShowTab("Wynagrodzenia", frm);
                SalariesForm.tabIsOpen = true;
            }
        }

        private void btnDepartaments_Click(object sender, EventArgs e)
        {
            if (DepartamentsForm.tabIsOpen == false)
            {
                DepartamentsForm frm = new DepartamentsForm();
                ShowTab("Działy", frm);
                DepartamentsForm.tabIsOpen = true;
            }
        }

        private void btnPositions_Click(object sender, EventArgs e)
        {
            if (PositionsForm.tabIsOpen == false)
            {
                PositionsForm frm = new PositionsForm();
                ShowTab("Stanowiska", frm);
                PositionsForm.tabIsOpen = true;
            }
        }
        private string closeButtonFullPath = @"C:\Users\Kamil\Desktop\TFS\SystemHR\SystemHR\Resources\close.png";

        private void tcTabs_DrawItem(object sender, DrawItemEventArgs e)
        {
            try
            {
                var tabPage = this.tcTabs.TabPages[e.Index];
                var tabRect = this.tcTabs.GetTabRect(e.Index);
                var closeImage = new Bitmap(closeButtonFullPath);
                e.Graphics.DrawImage(closeImage,
                (tabRect.Right - closeImage.Width),
                tabRect.Top + (tabRect.Height - closeImage.Height) / 2);
                TextRenderer.DrawText(e.Graphics, tabPage.Text, tabPage.Font,
                tabRect, tabPage.ForeColor, TextFormatFlags.Left);
            }
            catch (Exception ex) { throw new Exception(ex.Message); }
        }

        private void tcTabs_MouseDown(object sender, MouseEventArgs e)
        {
            for (var i = 0; i < this.tcTabs.TabPages.Count; i++)
            {
                var tabRect = this.tcTabs.GetTabRect(i);
                tabRect.Inflate(-2, -2);
                var closeImage = new Bitmap(closeButtonFullPath);
                var imageRect = new Rectangle(
                    (tabRect.Right - closeImage.Width),
                    tabRect.Top + (tabRect.Height - closeImage.Height) / 2,
                    closeImage.Width,
                    closeImage.Height);
                if (imageRect.Contains(e.Location))
                {
                    this.tcTabs.TabPages.RemoveAt(i);
                    break;
                }
            }
            EmployeesForm.tabIsOpen = false;
            ContractsForm.tabIsOpen = false;
            OrganizationStructureForm.tabIsOpen = false;
            SalariesForm.tabIsOpen = false;
            DepartamentsForm.tabIsOpen = false;
            PositionsForm.tabIsOpen = false;
        }
        #endregion
        #region public methods
        public void ShowTab(string title, Form frm)
        {
            TabPage tpTab = new TabPage();
            tcTabs.Controls.Add(tpTab);
            tpTab.Text = title;
            frm.TopLevel = false;
            frm.Visible = true;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;
            tpTab.Controls.Add(frm);
        }
        #endregion 
    }
}
