﻿namespace SystemHR.UserInterface.Forms
{
    partial class DataBaseConnectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tlpConfiguration = new System.Windows.Forms.TableLayoutPanel();
            this.pConfiguration = new System.Windows.Forms.Panel();
            this.lblConfiguration = new System.Windows.Forms.Label();
            this.pUpper = new System.Windows.Forms.Panel();
            this.pLower = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblServerName = new System.Windows.Forms.Label();
            this.txtServerName = new System.Windows.Forms.TextBox();
            this.lblDataBaseName = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtDataBaseName = new System.Windows.Forms.TextBox();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.tlpConfiguration.SuspendLayout();
            this.pConfiguration.SuspendLayout();
            this.pUpper.SuspendLayout();
            this.pLower.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlpConfiguration
            // 
            this.tlpConfiguration.ColumnCount = 1;
            this.tlpConfiguration.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpConfiguration.Controls.Add(this.pConfiguration, 0, 1);
            this.tlpConfiguration.Controls.Add(this.pUpper, 0, 0);
            this.tlpConfiguration.Controls.Add(this.pLower, 0, 2);
            this.tlpConfiguration.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpConfiguration.Location = new System.Drawing.Point(0, 0);
            this.tlpConfiguration.Name = "tlpConfiguration";
            this.tlpConfiguration.RowCount = 3;
            this.tlpConfiguration.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tlpConfiguration.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpConfiguration.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tlpConfiguration.Size = new System.Drawing.Size(405, 355);
            this.tlpConfiguration.TabIndex = 0;
            // 
            // pConfiguration
            // 
            this.pConfiguration.Controls.Add(this.txtPassword);
            this.pConfiguration.Controls.Add(this.txtUserName);
            this.pConfiguration.Controls.Add(this.txtDataBaseName);
            this.pConfiguration.Controls.Add(this.lblPassword);
            this.pConfiguration.Controls.Add(this.lblUserName);
            this.pConfiguration.Controls.Add(this.lblDataBaseName);
            this.pConfiguration.Controls.Add(this.txtServerName);
            this.pConfiguration.Controls.Add(this.lblServerName);
            this.pConfiguration.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pConfiguration.Location = new System.Drawing.Point(3, 53);
            this.pConfiguration.Name = "pConfiguration";
            this.pConfiguration.Size = new System.Drawing.Size(399, 249);
            this.pConfiguration.TabIndex = 0;
            // 
            // lblConfiguration
            // 
            this.lblConfiguration.AutoSize = true;
            this.lblConfiguration.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblConfiguration.Location = new System.Drawing.Point(9, 6);
            this.lblConfiguration.Name = "lblConfiguration";
            this.lblConfiguration.Size = new System.Drawing.Size(128, 30);
            this.lblConfiguration.TabIndex = 1;
            this.lblConfiguration.Text = "Konfiguracja";
            // 
            // pUpper
            // 
            this.pUpper.Controls.Add(this.lblConfiguration);
            this.pUpper.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pUpper.Location = new System.Drawing.Point(3, 3);
            this.pUpper.Name = "pUpper";
            this.pUpper.Size = new System.Drawing.Size(399, 44);
            this.pUpper.TabIndex = 1;
            // 
            // pLower
            // 
            this.pLower.Controls.Add(this.btnSave);
            this.pLower.Controls.Add(this.btnCancel);
            this.pLower.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pLower.Location = new System.Drawing.Point(3, 308);
            this.pLower.Name = "pLower";
            this.pLower.Size = new System.Drawing.Size(399, 44);
            this.pLower.TabIndex = 2;
            // 
            // btnCancel
            // 
            this.btnCancel.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnCancel.Location = new System.Drawing.Point(294, 0);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(105, 44);
            this.btnCancel.TabIndex = 0;
            this.btnCancel.Text = "Anuluj";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnSave.Location = new System.Drawing.Point(189, 0);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(105, 44);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "Zapisz";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblServerName
            // 
            this.lblServerName.AutoSize = true;
            this.lblServerName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblServerName.Location = new System.Drawing.Point(14, 19);
            this.lblServerName.Name = "lblServerName";
            this.lblServerName.Size = new System.Drawing.Size(97, 17);
            this.lblServerName.TabIndex = 0;
            this.lblServerName.Text = "Nazwa serwera";
            // 
            // txtServerName
            // 
            this.txtServerName.Location = new System.Drawing.Point(208, 19);
            this.txtServerName.Name = "txtServerName";
            this.txtServerName.Size = new System.Drawing.Size(182, 20);
            this.txtServerName.TabIndex = 1;
            // 
            // lblDataBaseName
            // 
            this.lblDataBaseName.AutoSize = true;
            this.lblDataBaseName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblDataBaseName.Location = new System.Drawing.Point(14, 70);
            this.lblDataBaseName.Name = "lblDataBaseName";
            this.lblDataBaseName.Size = new System.Drawing.Size(123, 17);
            this.lblDataBaseName.TabIndex = 2;
            this.lblDataBaseName.Text = "Nazwa bazy danych";
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblUserName.Location = new System.Drawing.Point(14, 128);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(120, 17);
            this.lblUserName.TabIndex = 3;
            this.lblUserName.Text = "Nazwa użytkownika";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPassword.Location = new System.Drawing.Point(14, 187);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(41, 17);
            this.lblPassword.TabIndex = 4;
            this.lblPassword.Text = "Hasło";
            // 
            // txtDataBaseName
            // 
            this.txtDataBaseName.Location = new System.Drawing.Point(208, 70);
            this.txtDataBaseName.Name = "txtDataBaseName";
            this.txtDataBaseName.Size = new System.Drawing.Size(182, 20);
            this.txtDataBaseName.TabIndex = 5;
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(208, 128);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(182, 20);
            this.txtUserName.TabIndex = 6;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(208, 184);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(182, 20);
            this.txtPassword.TabIndex = 7;
            // 
            // DataBaseConnectForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 355);
            this.Controls.Add(this.tlpConfiguration);
            this.Name = "DataBaseConnectForm";
            this.Text = "Konfiguracja połączenia";
            this.tlpConfiguration.ResumeLayout(false);
            this.pConfiguration.ResumeLayout(false);
            this.pConfiguration.PerformLayout();
            this.pUpper.ResumeLayout(false);
            this.pUpper.PerformLayout();
            this.pLower.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpConfiguration;
        private System.Windows.Forms.Panel pConfiguration;
        private System.Windows.Forms.Panel pUpper;
        private System.Windows.Forms.Label lblConfiguration;
        private System.Windows.Forms.Panel pLower;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtServerName;
        private System.Windows.Forms.Label lblServerName;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.TextBox txtDataBaseName;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Label lblDataBaseName;
    }
}