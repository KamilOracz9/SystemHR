﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.ViewModels;

namespace SystemHR.UserInterface.Forms.Salaries
{
    public partial class SalariesForm : Form
    {
        #region fields
        public static bool tabIsOpen = false;
        #endregion
        #region constructors
        public SalariesForm()
        {
            InitializeComponent();
            LoadSalariesData();
            LoadEmployeeData();
        }
        #endregion
        #region private methods
        private void LoadSalariesData()
        {
            SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
            SqlCommand loadSalariesData = new SqlCommand("select * from SalaryViewModel", con);
            con.Open();
            SqlDataAdapter dataAdapter = new SqlDataAdapter(loadSalariesData);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            bsSalaries.DataSource = dataTable;
            dgvSalaries.DataSource = bsSalaries;
            con.Close();
        }

        private void LoadEmployeeData()
        {
            SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
            SqlCommand loadEmployeeData = new SqlCommand($"select * from DefaultEmployeeData where Code=@Code", con);
            con.Open();
            loadEmployeeData.Parameters.AddWithValue("@Code", GetCode());
            SqlDataReader dataReader = null;
            dataReader = loadEmployeeData.ExecuteReader();
            while (dataReader.Read())
            {
                txtLastName.Text = (dataReader["Nazwisko"].ToString());
                txtFirstName.Text = (dataReader["Imię"].ToString());
                txtGender.Text = (dataReader["Płeć"].ToString());
                txtPESEL.Text = (dataReader["PESEL"].ToString());
                txtDateBitrth.Text = (dataReader["Data urodzenia"].ToString());
                txtStatus.Text = (dataReader["Status"].ToString());
                txtPosition.Text = (dataReader["Position"].ToString());
            }
            con.Close();
        }
        private int GetCode()
        {
            int colValue = Convert.ToInt32(dgvSalaries.CurrentRow.Cells["colCode"].Value);
            return colValue;
        }
        #endregion
    }
}
