﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Classes;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Models.Dictionaries;
using SystemHR.DataAccessLayer.ViewModels;
using SystemHR.UserInterface.Forms.Base;
using SystemHR.UserInterface.Helpers;

namespace SystemHR.UserInterface.Forms.Departaments
{
    public partial class DepartamentEditForm : BaseForm
    {
        #region fields
        public static DepartamentsForm DepartamentTable = (DepartamentsForm)Application.OpenForms["DepartamentsForm"];
        #endregion
        #region constructores
        public DepartamentEditForm()
        {
            InitializeComponent();
            InitializeData();
            LoadData();
            ValidateData();
        }
        #endregion
        #region private methods
        private void ValidateData()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                epName.SetError(txtName, "Pole nazwa jest wymagane");
            }
            else epName.Clear();
        }

        private void InitializeData()
        {
            IList<Departament> departaments = new List<Departament>()
            {
                new Departament("Produkcja"),
                new Departament(string.Empty)
            };
            bsParentDepartament.DataSource = departaments;
            cbParentDepartament.Text = string.Empty;
        }

        private void LoadData()
        {
            SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
            SqlCommand loadData = new SqlCommand("select * from DepartamentModel",con);
            con.Open();
            SqlDataReader dataReader = loadData.ExecuteReader();
            while (dataReader.Read())
            {
                txtName.Text = (dataReader["Name"].ToString());
                txtManagerLastName.Text = (dataReader["ManagerLastName"].ToString());
                txtManagerFirstName.Text = (dataReader["ManagerFirstname"].ToString());
                txtLocation.Text = (dataReader["Location"].ToString());
                cbParentDepartament.Text = (dataReader["ParentDepartament"].ToString());
                lblDepartament.Text = $"{(dataReader["Name"].ToString())}";
            }
            con.Close();
        }
        #endregion
        #region events
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidationForm())
            {
                SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
                SqlCommand updateDepartament = new SqlCommand($"update DepartamentModel set Name=@Name,ManagerLastName=@ManagerLastName,ManagerFirstName=@ManagerFirstName,Location=@Location,ParentDepartament=@ParentDepartament where Name=@LastUsingName",con);
                con.Open();
                updateDepartament.Parameters.AddWithValue("@LastUsingName", DepartamentTable.GetName());
                updateDepartament.Parameters.AddWithValue("@Name", txtName.Text);
                updateDepartament.Parameters.AddWithValue("@ManagerLastName", txtManagerLastName.Text);
                updateDepartament.Parameters.AddWithValue("@ManagerFirstName", txtManagerFirstName.Text);
                updateDepartament.Parameters.AddWithValue("@Location", txtLocation.Text);
                updateDepartament.Parameters.AddWithValue("@ParentDepartament", cbParentDepartament.Text);
                updateDepartament.ExecuteNonQuery();
                con.Close();
                Close();
                DepartamentTable.LoadData();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            ValidateData();
        }
        private bool ValidationForm()
        {
            StringBuilder sbErrorMessage = new StringBuilder();
            string nameErrorMessage = epName.GetError(txtName);
            if (nameErrorMessage.Length > 0)
            {
                sbErrorMessage.Append(nameErrorMessage);
                MessageBox.Show(nameErrorMessage.ToString(),
                    "Modyfikowanie działu",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        #endregion
    }
}
