﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Classes;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Models.Dictionaries;
using SystemHR.UserInterface.Forms.Base;
using SystemHR.UserInterface.Helpers;

namespace SystemHR.UserInterface.Forms.Departaments
{
    public partial class DepartamentsAddForm : BaseForm
    {
        #region fields
        public static DepartamentsForm DepartamentTable = (DepartamentsForm)Application.OpenForms["DepartamentsForm"];
        #endregion
        #region construktors
        public DepartamentsAddForm()
        {
            InitializeComponent();
            InitializeData();
            ValidateData();
        }
        #endregion
        #region private methods
        private void ValidateData()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                epName.SetError(txtName, "Pole Nazwa jest wymagane");
            }
            else epName.Clear();
        }

        private void InitializeData()
        {
            IList<Departament> departaments = new List<Departament>()
            {
                new Departament("Produkcja"),
                new Departament(string.Empty)
            };
            bsParentDepartament.DataSource = departaments;
            cbParentDepartament.Text = string.Empty;
        }
        private bool ValidationForm()
        {
            StringBuilder sbErrorMessage = new StringBuilder();
            string nameErrorMessage = epName.GetError(txtName);
            if (nameErrorMessage.Length > 0)
            {
                sbErrorMessage.Append(nameErrorMessage);
                MessageBox.Show(
                    sbErrorMessage.ToString(),
                    "Dodawanie Działu",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        #endregion
        #region events
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidationForm())
            {
                SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
                SqlCommand insertDepartament = new SqlCommand("insert into DepartamentModel (ManagerLastName,ManagerFirstname,Name,Location,ParentDepartament)values(@ManagerLastName,@ManagerFirstname,@Name,@Location,@ParentDepartament)", con);
                con.Open();
                insertDepartament.Parameters.AddWithValue("@ManagerLastName",txtManagerLastName.Text);
                insertDepartament.Parameters.AddWithValue("@ManagerFirstName", txtManagerFirstName.Text);
                insertDepartament.Parameters.AddWithValue("@Name", txtName.Text);
                insertDepartament.Parameters.AddWithValue("@Location", txtLocation.Text);
                insertDepartament.Parameters.AddWithValue("@ParentDepartament", cbParentDepartament.Text);
                insertDepartament.ExecuteNonQuery();
                con.Close();
                Close();
                DepartamentTable.LoadData();
            }

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            ValidateData();
        }
        #endregion
    }
}
