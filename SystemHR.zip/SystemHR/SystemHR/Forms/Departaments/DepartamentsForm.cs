﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Classes;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Models.Dictionaries;
using SystemHR.DataAccessLayer.ViewModels;
using SystemHR.UserInterface.Forms.OrganizationStructure;
using SystemHR.UserInterface.Helpers;

namespace SystemHR.UserInterface.Forms.Departaments
{
    public partial class DepartamentsForm : Form
    {
        #region fields
        public static bool tabIsOpen = false;
        public static OrganizationStructureForm organizationStructureTable = (OrganizationStructureForm)Application.OpenForms["OrganizationStructureForm"];
        #endregion
        #region constructors
        public DepartamentsForm()
        {
            InitializeComponent();
            LoadData();
        }
        #endregion
        #region private methods
        private void DepartamentsForm_Load(object sender, EventArgs e)
        {
            // TODO: Ten wiersz kodu wczytuje dane do tabeli 'systemHRDataSet8.DepartamentViewModel' . Możesz go przenieść lub usunąć.
            this.taDepartaments.Fill(this.dsDepartaments.DepartamentViewModel);

        }
        #endregion
        #region events
        private void btnCreate_Click(object sender, EventArgs e)
        {
            DepartamentsAddForm frm = new DepartamentsAddForm();
            frm.ShowDialog();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (dgvDepartaments.Rows.Count > 0)
            {
                SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
                SqlCommand removeDepartament = new SqlCommand($"delete from DepartamentModel where Name = @Name",con);
                con.Open();
                removeDepartament.Parameters.AddWithValue("@Name",GetName());
                removeDepartament.ExecuteNonQuery();
                con.Close();
                LoadData();
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            if (dgvDepartaments.Rows.Count > 0)
            {
                DepartamentEditForm frm = new DepartamentEditForm();
                frm.ShowDialog();
            }
        }
        #endregion
        #region public methods
        public string GetName()
        {
            string colValue = dgvDepartaments.CurrentRow.Cells["colName"].Value.ToString();
            return colValue;
        }
        public int GetRowId()
        {
            int rowId = Convert.ToInt32(dgvDepartaments.CurrentRow.Cells["colId"].Value);
            return rowId;
        }
        public int selectedRowIndex()
        {
            int index = dgvDepartaments.CurrentRow.Index;
            return index;
        }
        public void LoadData()
        {
            SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
            SqlCommand loadData = new SqlCommand("select * from DepartamentViewModel", con);
            con.Open();
            SqlDataAdapter dataAdapter = new SqlDataAdapter(loadData);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            bsDepartaments.DataSource = dataTable;
            dgvDepartaments.DataSource = bsDepartaments;
            con.Close();
        }
        #endregion
    }
}
