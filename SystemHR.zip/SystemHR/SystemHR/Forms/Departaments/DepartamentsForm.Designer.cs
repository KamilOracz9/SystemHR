﻿namespace SystemHR.UserInterface.Forms.Departaments
{
    partial class DepartamentsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pDepartaments = new System.Windows.Forms.Panel();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnModify = new System.Windows.Forms.Button();
            this.btnCreate = new System.Windows.Forms.Button();
            this.dgvDepartaments = new System.Windows.Forms.DataGridView();
            this.dsDepartaments = new SystemHR.UserInterface.SystemHRDataSet8();
            this.bsDepartaments = new System.Windows.Forms.BindingSource(this.components);
            this.taDepartaments = new SystemHR.UserInterface.SystemHRDataSet8TableAdapters.DepartamentViewModelTableAdapter();
            this.colId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colManager = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLocalization = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colParentDepartament = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel1.SuspendLayout();
            this.pDepartaments.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDepartaments)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsDepartaments)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsDepartaments)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.pDepartaments, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.dgvDepartaments, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(841, 479);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pDepartaments
            // 
            this.pDepartaments.Controls.Add(this.btnRefresh);
            this.pDepartaments.Controls.Add(this.btnRemove);
            this.pDepartaments.Controls.Add(this.btnModify);
            this.pDepartaments.Controls.Add(this.btnCreate);
            this.pDepartaments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pDepartaments.Location = new System.Drawing.Point(3, 3);
            this.pDepartaments.Name = "pDepartaments";
            this.pDepartaments.Size = new System.Drawing.Size(835, 34);
            this.pDepartaments.TabIndex = 0;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnRefresh.Location = new System.Drawing.Point(357, 0);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(119, 34);
            this.btnRefresh.TabIndex = 3;
            this.btnRefresh.Text = "Odśwież";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnRemove.Location = new System.Drawing.Point(238, 0);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(119, 34);
            this.btnRemove.TabIndex = 2;
            this.btnRemove.Text = "Usuń";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnModify
            // 
            this.btnModify.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnModify.Location = new System.Drawing.Point(119, 0);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(119, 34);
            this.btnModify.TabIndex = 1;
            this.btnModify.Text = "Modyfikuj";
            this.btnModify.UseVisualStyleBackColor = true;
            this.btnModify.Click += new System.EventHandler(this.btnModify_Click);
            // 
            // btnCreate
            // 
            this.btnCreate.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnCreate.Location = new System.Drawing.Point(0, 0);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(119, 34);
            this.btnCreate.TabIndex = 0;
            this.btnCreate.Text = "Dodaj";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // dgvDepartaments
            // 
            this.dgvDepartaments.AllowUserToAddRows = false;
            this.dgvDepartaments.AllowUserToDeleteRows = false;
            this.dgvDepartaments.AutoGenerateColumns = false;
            this.dgvDepartaments.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvDepartaments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDepartaments.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colId,
            this.colName,
            this.colManager,
            this.colLocalization,
            this.colParentDepartament});
            this.dgvDepartaments.DataSource = this.bsDepartaments;
            this.dgvDepartaments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDepartaments.GridColor = System.Drawing.SystemColors.Control;
            this.dgvDepartaments.Location = new System.Drawing.Point(3, 43);
            this.dgvDepartaments.Name = "dgvDepartaments";
            this.dgvDepartaments.ReadOnly = true;
            this.dgvDepartaments.RowHeadersVisible = false;
            this.dgvDepartaments.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDepartaments.Size = new System.Drawing.Size(835, 433);
            this.dgvDepartaments.TabIndex = 1;
            // 
            // dsDepartaments
            // 
            this.dsDepartaments.DataSetName = "SystemHRDataSet8";
            this.dsDepartaments.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bsDepartaments
            // 
            this.bsDepartaments.DataMember = "DepartamentViewModel";
            this.bsDepartaments.DataSource = this.dsDepartaments;
            // 
            // taDepartaments
            // 
            this.taDepartaments.ClearBeforeFill = true;
            // 
            // colId
            // 
            this.colId.DataPropertyName = "Id";
            this.colId.HeaderText = "Id";
            this.colId.Name = "colId";
            this.colId.ReadOnly = true;
            this.colId.Visible = false;
            // 
            // colName
            // 
            this.colName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colName.DataPropertyName = "Nazwa";
            this.colName.HeaderText = "Nazwa";
            this.colName.Name = "colName";
            this.colName.ReadOnly = true;
            // 
            // colManager
            // 
            this.colManager.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colManager.DataPropertyName = "Kierownik działu";
            this.colManager.HeaderText = "Kierownik działu";
            this.colManager.Name = "colManager";
            this.colManager.ReadOnly = true;
            // 
            // colLocalization
            // 
            this.colLocalization.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colLocalization.DataPropertyName = "Lokalizacja";
            this.colLocalization.HeaderText = "Lokalizacja";
            this.colLocalization.Name = "colLocalization";
            this.colLocalization.ReadOnly = true;
            // 
            // colParentDepartament
            // 
            this.colParentDepartament.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colParentDepartament.DataPropertyName = "Dział nadrzędny";
            this.colParentDepartament.HeaderText = "Dział nadrzędny";
            this.colParentDepartament.Name = "colParentDepartament";
            this.colParentDepartament.ReadOnly = true;
            // 
            // DepartamentsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 479);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "DepartamentsForm";
            this.ShowIcon = false;
            this.Text = "Działy";
            this.Load += new System.EventHandler(this.DepartamentsForm_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.pDepartaments.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDepartaments)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsDepartaments)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsDepartaments)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel pDepartaments;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnModify;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.DataGridView dgvDepartaments;
        private SystemHRDataSet8 dsDepartaments;
        private System.Windows.Forms.BindingSource bsDepartaments;
        private SystemHRDataSet8TableAdapters.DepartamentViewModelTableAdapter taDepartaments;
        private System.Windows.Forms.DataGridViewTextBoxColumn colId;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colManager;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLocalization;
        private System.Windows.Forms.DataGridViewTextBoxColumn colParentDepartament;
    }
}