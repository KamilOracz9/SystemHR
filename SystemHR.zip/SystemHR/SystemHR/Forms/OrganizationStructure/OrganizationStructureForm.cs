﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.ViewModels;

namespace SystemHR.UserInterface.Forms.OrganizationStructure
{
    public partial class OrganizationStructureForm : Form
    {
        #region fields
        public static bool tabIsOpen = false;
        #endregion
        #region constructors
        public OrganizationStructureForm()
        {
            InitializeComponent();
            LoadData();
        }
        #endregion
        #region private methods
        private void OrganizationStructureForm_Load(object sender, EventArgs e)
        {
            // TODO: Ten wiersz kodu wczytuje dane do tabeli 'systemHRDataSet7.OrganizationStructureViewModel' . Możesz go przenieść lub usunąć.
            this.taOrganizationStructure.Fill(this.dsOrganizationStructure.OrganizationStructureViewModel);

        }
        #endregion
        #region public methods
        public void LoadData()
        {
            SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
            SqlCommand loadData = new SqlCommand("select * from OrganizationStructureViewModel", con);
            con.Open();
            SqlDataAdapter dataAdapter = new SqlDataAdapter(loadData);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            bsOrganizationStructure.DataSource = dataTable;
            dgvOrganizationStructure.DataSource = bsOrganizationStructure;
            con.Close();
        }
        #endregion
    }
}
