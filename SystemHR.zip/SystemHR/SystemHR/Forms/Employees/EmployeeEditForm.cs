﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Classes;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Models.Dictionaries;
using SystemHR.DataAccessLayer.ViewModels;
using SystemHR.UserInterface.Extensions;
using SystemHR.UserInterface.Forms.Base;
using SystemHR.UserInterface.Helpers;

namespace SystemHR.UserInterface.Forms.Employees
{
    public partial class EmployeeEditForm : BaseForm
    {

        #region fields
        public static EmployeesForm EmployeeTable = (EmployeesForm)Application.OpenForms["EmployeesForm"];
        #endregion
        #region constructor
        public EmployeeEditForm()
        {
            InitializeComponent();
            InitializeData();
            LoadData();
            ValidateControls();
        }

        #endregion
        #region private methods
        private void LoadData()
        {
            SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
            con.Open();
            SqlDataReader readData = null;
            SqlCommand cmd = new SqlCommand($"select * from EmployeeModel where Code={EmployeeTable.GetCode()}",con);

            readData = cmd.ExecuteReader();

            while (readData.Read())
            {
                txtLastName.Text = (readData["LastName"].ToString());
                txtFirstName.Text = (readData["FirstName"].ToString());
                cbGender.Text = (readData["Gender"].ToString());
                dtpDateBirth.Text = (readData["DateBirth"].ToString());
                txtPESEL.Text = (readData["PESEL"].ToString());
                txtPhoneNumber.Text = (readData["PhoneNumber"].ToString());
                txtEmailAdress.Text = (readData["EmailAdress"].ToString());
                txtIdentityNumber.Text = (readData["IdentityCardNumber"].ToString());
                dtpIssueDateIdentityCard.Text = (readData["IssueDateIdentityCard"].ToString());
                dtpExpirationDateIdentityCard.Text = (readData["ExpirationDateIdentityCard"].ToString());
                dtpIssueDatePassport.Text = (readData["IssueDatePassport"].ToString());
                dtpExpirationDataPassport.Text = (readData["ExpirationDatePassport"].ToString());
                lblEmployee.Text = $"{(readData["FirstName"].ToString())}"+" "+$"{(readData["LastName"].ToString())}"+$" ({(readData["Code"].ToString())})"+" - "+$"{(readData["Status"].ToString())}";
            }
            con.Close();
        }
        private void ValidateControls()
        {
            if (string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                epLastName.SetError(txtLastName, "Pole nazwisko jest wymagane!");
            }
            else
            {
                epLastName.Clear();
            }
            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                epFirstName.SetError(txtFirstName, "Pole imię jest wymagane!");
            }
            else
            {
                epFirstName.Clear();
            }
            if (!string.IsNullOrWhiteSpace(txtPESEL.Text) && !ValidatorHelper.IsValidPESEL(txtPESEL.Text))
            {
                epPESEL.SetError(txtPESEL, "PESEL jest nieprawidłowy");
            }
            else
            {
                epPESEL.Clear();
            }
        }

        private void InitializeData()
        {
            IList<GenderModel> genders = new List<GenderModel>()
            {
                new GenderModel("Kobieta"),
                new GenderModel("Mężczyzna"),
                new GenderModel(string.Empty)
            };
            bsGender.DataSource = genders;
            cbGender.Text = string.Empty;
        }

        

        private bool ValidateForm()
        {
            StringBuilder sbErrorMessage = new StringBuilder();
            string lastNameErrorMessage = epLastName.GetError(txtLastName);
            if (!string.IsNullOrEmpty(lastNameErrorMessage))
            {
                sbErrorMessage.Append(lastNameErrorMessage);
            }
            string firstNameErrorMessage = epFirstName.GetError(txtFirstName);
            if (!string.IsNullOrEmpty(firstNameErrorMessage))
            {
                sbErrorMessage.Append(firstNameErrorMessage);
            }
            if (sbErrorMessage.Length > 0)
            {
                MessageBox.Show(
                    sbErrorMessage.ToString(),
                    "Dodawanie pracownika",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
            string peselWarningMessage = epPESEL.GetError(txtPESEL);
            if (!string.IsNullOrEmpty(peselWarningMessage))
            {
                DialogResult answer =
                    MessageBox.Show(
                        peselWarningMessage + Environment.NewLine + "PESEL jest nieprawidłowy, czy mimo to chcesz dodać nowego pracownika?",
                        "Dodawanie pracownika",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Warning);
                if (answer == DialogResult.No)
                {
                    return false;
                }
            }
            return true;
        }
        #endregion
        #region events
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateForm())
            {
                SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
                SqlCommand updateEmployeeModelData = new SqlCommand($"update EmployeeModel set LastName=@LastName,FirstName=@FirstName,Gender=@Gender,DateBirth=@DateBirth,PESEL=@PESEL,PhoneNumber=@PhoneNumber,EmailAdress=@EmailAdress,IdentityCardNumber=@IdentityCardNumber,IssueDateIdentityCard=@IssueDateIdentityCard,ExpirationDateIdentityCard=@ExpirationDateIdentityCard,PassportNumber=@PassportNumber,IssueDatePassport=@IssueDatePassport,ExpirationDatePassport=@ExpirationDatePassport where Code={EmployeeTable.GetCode()}", con);
                SqlCommand updateContractModelData = new SqlCommand($"update ContractModel set LastName=@LastName,FirstName=@FirstName where Code={EmployeeTable.GetCode()}", con);
                con.Open();
                updateEmployeeModelData.Parameters.AddWithValue("@LastName", txtLastName.Text);
                updateEmployeeModelData.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                updateEmployeeModelData.Parameters.AddWithValue("@Gender", cbGender.Text);
                updateEmployeeModelData.Parameters.AddWithValue("@DateBirth", dtpDateBirth.Value);
                updateEmployeeModelData.Parameters.AddWithValue("@PESEL", txtPESEL.Text);
                updateEmployeeModelData.Parameters.AddWithValue("@PhoneNumber", txtPhoneNumber.Text);
                updateEmployeeModelData.Parameters.AddWithValue("@EmailAdress", txtEmailAdress.Text);
                updateEmployeeModelData.Parameters.AddWithValue("@IdentityCardNumber", txtIdentityNumber.Text);
                updateEmployeeModelData.Parameters.AddWithValue("@IssueDateIdentityCard", dtpIssueDateIdentityCard.Value);
                updateEmployeeModelData.Parameters.AddWithValue("@ExpirationDateIdentityCard", dtpExpirationDateIdentityCard.Value);
                updateEmployeeModelData.Parameters.AddWithValue("@PassportNumber", txtPassportNumber.Text);
                updateEmployeeModelData.Parameters.AddWithValue("@IssueDatePassport", dtpIssueDatePassport.Value);
                updateEmployeeModelData.Parameters.AddWithValue("@ExpirationDatePassport", dtpExpirationDataPassport.Value);
                updateEmployeeModelData.ExecuteNonQuery();
                updateContractModelData.Parameters.AddWithValue("@LastName", txtLastName.Text);
                updateContractModelData.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                updateContractModelData.ExecuteNonQuery();
                con.Close();
                EmployeeTable.LoadData();
                Close();
            }

        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dtp_ValueChanged(object sender, EventArgs e)
        {
            DateTimePicker dtp = sender as DateTimePicker;
            dtp.DateTimePickerValueChanged();
        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {
            ValidateControls();
        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {
            ValidateControls();
        }

        private void txtPESEL_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtPESEL_Validated(object sender, EventArgs e)
        {
            string pesel = txtPESEL.Text;
            if (!string.IsNullOrWhiteSpace(pesel) && !ValidatorHelper.IsValidPESEL(pesel))
            {
                epPESEL.SetError(txtPESEL, "PESEL jest nieprawidłowy");
            }
            else
            {
                epPESEL.Clear();
            }
        }
        #endregion
    }
}
