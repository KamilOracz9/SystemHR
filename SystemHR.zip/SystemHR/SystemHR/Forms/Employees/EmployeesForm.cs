﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Classes;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Models.Dictionaries;
using SystemHR.DataAccessLayer.ViewModels;
using SystemHR.UserInterface.Helpers;

namespace SystemHR.UserInterface.Forms.Employees
{
    public partial class EmployeesForm : Form
    {
        #region fields
        public static bool tabIsOpen = false;
        #endregion
        #region constructor
        public EmployeesForm()
        {
            InitializeComponent();
            LoadData();
        }
        #endregion
        #region private methods
        private void EmployeesForm_Load(object sender, EventArgs e)
        {
            // TODO: Ten wiersz kodu wczytuje dane do tabeli 'systemHRDataSet4.EmployeeViewModel' . Możesz go przenieść lub usunąć.
            this.employeeViewModelTableAdapter.Fill(this.systemHRDataSet.EmployeeViewModel);
        }
        #endregion
        #region events
        private void btnCreate_Click(object sender, EventArgs e)
        {
            EmployeeAddForm frm = new EmployeeAddForm();
            frm.ShowDialog();
        }
        private void btnModify_Click(object sender, EventArgs e)
        {
            if (dgvEmployees.Rows.Count > 0)
            {
                EmployeeEditForm frm = new EmployeeEditForm();
                frm.ShowDialog();
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (dgvEmployees.Rows.Count > 0)
            {
                SqlConnection Con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
                string EmployeeRemove = $"delete from EmployeeModel where Code = {GetCode()}";
                string ContractRemove = $"delete from ContractModel where Code = {GetCode()}";
                SqlCommand cmdEmployeeRemove = new SqlCommand(EmployeeRemove, Con);
                SqlCommand cmdSqlContractRemove = new SqlCommand(ContractRemove, Con);
                Con.Open();
                cmdEmployeeRemove.ExecuteNonQuery();
                cmdSqlContractRemove.ExecuteNonQuery();
                MessageBox.Show("Usunięto pracownika");
                Con.Close();
                LoadData();
            }
        }
        private void btnDismiss_Click(object sender, EventArgs e)
        {
            if (dgvEmployees.Rows.Count > 0)
            {
                DialogResult answer =
                    MessageBox.Show(
                        "Czy napewno chcesz zwolnić pracownika?",
                        "Zwalnianie pracownika",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question);
                if (answer == DialogResult.Yes)
                {
                    SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
                    SqlCommand dismissEmployee = new SqlCommand($"update EmployeeModel set status = @status where code = {GetCode()}", con);
                    con.Open();
                    dismissEmployee.Parameters.AddWithValue("@status", "ZWOLNIONY");
                    dismissEmployee.ExecuteNonQuery();
                    con.Close();
                    LoadData();
                    MessageBox.Show("Zwolniono pracownika");
                }
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
            MessageBox.Show("Załadowano ponownie listę pracowników");
        }
        #endregion
        #region public methods
        public void LoadData()
        {
            SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.Connection = con;
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "SELECT * FROM dbo.EmployeeViewModel order by Kod;";
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCmd);
            DataTable dtRecord = new DataTable();
            sqlDataAdapter.Fill(dtRecord);
            bsEmployees.DataSource = dtRecord;
            dgvEmployees.DataSource = bsEmployees;
        }
       
        public int GetCode()
        {
            int colValue = Convert.ToInt32(dgvEmployees.CurrentRow.Cells["colCode"].Value);
            return colValue;
        }
        #endregion
    }
}
