﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Classes;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Models.Dictionaries;
using SystemHR.UserInterface.Extensions;
using SystemHR.UserInterface.Forms.Base;
using SystemHR.UserInterface.Helpers;

namespace SystemHR.UserInterface.Forms.Employees
{
    public partial class EmployeeAddForm : BaseForm
    {
        #region fields
        public EventHandler ReloadEmployees;
        EmployeesForm EmployeeTable = (EmployeesForm)Application.OpenForms["EmployeesForm"];
        #endregion
        #region constructors
        public EmployeeAddForm()
        {
            InitializeComponent();
            InitializeData();
            ValidateControls();
        }
        #endregion
        #region private methods
        private void ValidateControls()
        {
            if (string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                epLastName.SetError(txtLastName, "Pole nazwisko jest wymagane!");
            }
            else
            {
                epLastName.Clear();
            }
            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                epFirstName.SetError(txtFirstName, "Pole imię jest wymagane!");
            }
            else
            {
                epFirstName.Clear();
            }
        }

        private void InitializeData()
        {
            IList<GenderModel> genders = new List<GenderModel>()
            {
                new GenderModel("Kobieta"),
                new GenderModel("Mężczyzna"),
                new GenderModel(string.Empty)
            };
            bsGender.DataSource = genders;
            cbGender.Text = string.Empty;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateForm())
            {
                SqlConnection Con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
                string EmployeeInsert = "insert into dbo.EmployeeModel (LastName,FirstName,Gender,DateBirth,PESEL,PhoneNumber,EmailAdress,IdentityCardNumber,IssueDateIdentityCard,ExpirationDateIdentityCard,PassportNumber,IssueDatePassport,ExpirationDatePassport,Status)VALUES(@LastName,@FirstName, @Gender, @DateBirth, @PESEL, @PhoneNumber, @EmailAdress, @IdentityCardNumber, @IssueDateIdentityCard, @ExpirationDateIdentityCard, @PassportNumber, @IssueDatePassport, @ExpirationDatePassport, @Status)";
                string ContractInsert = "insert into dbo.ContractModel (LastName,FirstName)VALUES(@LastName,@FirstName)";
                SqlCommand cmdEmployeeInsert = new SqlCommand(EmployeeInsert, Con);
                cmdEmployeeInsert.Parameters.AddWithValue("@LastName", txtLastName.Text);
                cmdEmployeeInsert.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                cmdEmployeeInsert.Parameters.AddWithValue("@Gender", cbGender.Text);
                cmdEmployeeInsert.Parameters.AddWithValue("@DateBirth", dtpDateBirth.Value);
                cmdEmployeeInsert.Parameters.AddWithValue("@PESEL", txtPESEL.Text);
                cmdEmployeeInsert.Parameters.AddWithValue("@PhoneNumber", txtPhoneNumber.Text);
                cmdEmployeeInsert.Parameters.AddWithValue("@EmailAdress", txtEmailAdress.Text);
                cmdEmployeeInsert.Parameters.AddWithValue("@IdentityCardNumber", txtIdentityNumber.Text);
                cmdEmployeeInsert.Parameters.AddWithValue("@IssueDateIdentityCard", dtpIssueDateIdentityCard.Value);
                cmdEmployeeInsert.Parameters.AddWithValue("@ExpirationDateIdentityCard", dtpExpirationDateIdentityCard.Value);
                cmdEmployeeInsert.Parameters.AddWithValue("@PassportNumber", txtPassportNumber.Text);
                cmdEmployeeInsert.Parameters.AddWithValue("@IssueDatePassport", dtpIssueDatePassport.Value);
                cmdEmployeeInsert.Parameters.AddWithValue("@ExpirationDatePassport", dtpExpirationDataPassport.Value);
                cmdEmployeeInsert.Parameters.AddWithValue("@Status", new StatusModel("Wprowadzony").ToString());
                SqlCommand cmdContractInsert = new SqlCommand(ContractInsert, Con);
                cmdContractInsert.Parameters.AddWithValue("@LastName", txtLastName.Text);
                cmdContractInsert.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                Con.Open();
                cmdEmployeeInsert.ExecuteNonQuery();
                cmdContractInsert.ExecuteNonQuery();
                MessageBox.Show("Dodano Pracownika");
                Con.Close();
                EmployeeTable.LoadData();
                Close();
            }
        }

        private bool ValidateForm()
        {
            StringBuilder sbErrorMessage = new StringBuilder();
            string lastNameErrorMessage = epLastName.GetError(txtLastName);
            if (!string.IsNullOrEmpty(lastNameErrorMessage))
            {
                sbErrorMessage.Append(lastNameErrorMessage);
            }
            string firstNameErrorMessage = epFirstName.GetError(txtFirstName);
            if (!string.IsNullOrEmpty(firstNameErrorMessage))
            {
                sbErrorMessage.Append(firstNameErrorMessage);
            }
            if (sbErrorMessage.Length > 0)
            {
                MessageBox.Show(
                    sbErrorMessage.ToString(),
                    "Dodawanie pracownika",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
            string peselWarningMessage = epPESEL.GetError(txtPESEL);
            if (string.IsNullOrEmpty(peselWarningMessage))
            {
                DialogResult answer =
                    MessageBox.Show(
                        peselWarningMessage + Environment.NewLine + "PESEL jest nieprawidłowy, czy mimo to chcesz dodać nowego pracownika?",
                        "Dodawanie pracownika",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Warning);
                if (answer == DialogResult.No)
                {
                    return false;
                }
            }
            return true;
        }
        #endregion
        #region events
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dtp_ValueChanged(object sender, EventArgs e)
        {
            DateTimePicker dtp = sender as DateTimePicker;
            dtp.DateTimePickerValueChanged();
        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {
            ValidateControls();
        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {
            ValidateControls();
        }

        private void txtPESEL_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtPESEL_Validated(object sender, EventArgs e)
        {
            string pesel = txtPESEL.Text;
            if (!string.IsNullOrWhiteSpace(pesel) && !ValidatorHelper.IsValidPESEL(pesel))
            {
                epPESEL.SetError(txtPESEL, "PESEL jest nieprawidłowy");
            }
            else
            {
                epPESEL.Clear();
            }
        }
        #endregion
    }
}
