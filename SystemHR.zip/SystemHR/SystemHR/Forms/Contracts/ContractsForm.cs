﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Classes;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Models.Dictionaries;
using SystemHR.DataAccessLayer.ViewModels;
using SystemHR.UserInterface.Helpers;

namespace SystemHR.UserInterface.Forms.Contracts
{
    public partial class ContractsForm : Form
    {
        #region fields
        public static bool tabIsOpen = false;
        #endregion
        #region constructors
        public ContractsForm()
        {
            InitializeComponent();
            LoadData();
        }
        #endregion
        #region private methods
        private void ContractsForm_Load(object sender, EventArgs e)
        {
            // TODO: Ten wiersz kodu wczytuje dane do tabeli 'systemHRDataSet5.ContractViewModel' . Możesz go przenieść lub usunąć.
            this.contractViewModelTableAdapter.Fill(this.systemHRDataSet5.ContractViewModel);

        }

        #endregion
        #region events
        private void btnPreview_Click(object sender, EventArgs e)
        {
            if (dgvContracts.Rows.Count > 0)
            {
                ContractPreviewForm frm = new ContractPreviewForm();
                frm.ShowDialog();
            }
        }
        private void btnCreate_Click(object sender, EventArgs e)
        {
            ContractsAddForm frm = new ContractsAddForm();
            frm.ShowDialog();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (dgvContracts.Rows.Count > 0)
            {
                int selectedRowIndex = dgvContracts.CurrentRow.Index;
                SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
                SqlCommand removeContract = new SqlCommand($"update ContractModel set TypeContract=@TypeContract,Position=@Position where Code = {GetCode()}", con);
                con.Open();
                removeContract.Parameters.AddWithValue("@TypeContract", "NoContract");
                removeContract.Parameters.AddWithValue("@Position", string.Empty);
                removeContract.ExecuteNonQuery();
                con.Close();
                LoadData();
            }
        }
        #endregion
        #region public methods
        public void LoadData()
        {
            SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
            SqlCommand showData = new SqlCommand("select * from ContractViewModel where [Rodzaj umowy]is not null and [Rodzaj umowy]not like 'NoContract' order by Kod", con);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(showData);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            bsContracts.DataSource = dataTable;
            dgvContracts.DataSource = bsContracts;
        }
        public int GetCode()
        {
            int colValue = Convert.ToInt32(dgvContracts.CurrentRow.Cells["colCode"].Value);
            return colValue;
        }
        public string GetLastName()
        {
            string colValue = Convert.ToString(dgvContracts.CurrentRow.Cells["colLastName"].Value);
            return colValue;
        }
        public string GetFirstName()
        {
            string colValue = Convert.ToString(dgvContracts.CurrentRow.Cells["colFirstName"].Value);
            return colValue;
        }
        #endregion
    }
}
