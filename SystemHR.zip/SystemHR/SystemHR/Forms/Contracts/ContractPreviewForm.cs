﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.UserInterface.Forms.Base;

namespace SystemHR.UserInterface.Forms.Contracts
{
    public partial class ContractPreviewForm : BaseForm
    {
        #region fields
        ContractsForm ContractTable = (ContractsForm)Application.OpenForms["ContractsForm"];
        #endregion
        #region constructors
        public ContractPreviewForm()
        {
            InitializeComponent();
            LoadData();
        }
        #endregion
        #region private methods
        private void LoadData()
        {
            SqlConnection con = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=SystemHR;Integrated Security=SSPI;");
            SqlCommand showData = new SqlCommand($"select * from ContractModel where Code={ContractTable.GetCode()}", con);
            con.Open();
            SqlDataReader dataReader = null;
            dataReader = showData.ExecuteReader();
            while (dataReader.Read())
            {
                txtLastName.Text = (dataReader["LastName"].ToString());
                txtFirstName.Text = (dataReader["Lastname"].ToString());
                txtCode.Text = (dataReader["Code"].ToString());
                txtConclusionDate.Text = (dataReader["ConclusionDate"].ToString());
                txtDateFrom.Text = (dataReader["DateFrom"].ToString());
                txtDateTo.Text = (dataReader["DateTo"].ToString());
                txtPosition.Text = (dataReader["Position"].ToString());
                txtDepartament.Text = (dataReader["Departament"].ToString());
                txtSalary.Text = (dataReader["Salary"].ToString());
                txtCurrency.Text = (dataReader["Currency"].ToString());
                txtTypeRate.Text = (dataReader["TypeRate"].ToString());
                txtTypeContract.Text = (dataReader["TypeContract"].ToString());
                txtTerminationWay.Text = (dataReader["TerminationWay"].ToString());
            }
            con.Close();
        }
        #endregion
    }
}
