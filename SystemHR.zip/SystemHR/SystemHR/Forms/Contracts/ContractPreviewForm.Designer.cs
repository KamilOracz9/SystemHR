﻿namespace SystemHR.UserInterface.Forms.Contracts
{
    partial class ContractPreviewForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tlpPreview = new System.Windows.Forms.TableLayoutPanel();
            this.systemHRDataSet6 = new SystemHR.UserInterface.SystemHRDataSet6();
            this.pPreview = new System.Windows.Forms.Panel();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblCode = new System.Windows.Forms.Label();
            this.lblConclusionDate = new System.Windows.Forms.Label();
            this.lblDateFrom = new System.Windows.Forms.Label();
            this.lblDateTo = new System.Windows.Forms.Label();
            this.lblPosition = new System.Windows.Forms.Label();
            this.lblDepartament = new System.Windows.Forms.Label();
            this.lblSalary = new System.Windows.Forms.Label();
            this.lblCurrency = new System.Windows.Forms.Label();
            this.lblTypeRate = new System.Windows.Forms.Label();
            this.lblTypeContract = new System.Windows.Forms.Label();
            this.lblTerminationWay = new System.Windows.Forms.Label();
            this.txtTerminationWay = new System.Windows.Forms.TextBox();
            this.txtTypeRate = new System.Windows.Forms.TextBox();
            this.txtTypeContract = new System.Windows.Forms.TextBox();
            this.txtCurrency = new System.Windows.Forms.TextBox();
            this.txtSalary = new System.Windows.Forms.TextBox();
            this.txtDepartament = new System.Windows.Forms.TextBox();
            this.txtPosition = new System.Windows.Forms.TextBox();
            this.txtDateTo = new System.Windows.Forms.TextBox();
            this.txtDateFrom = new System.Windows.Forms.TextBox();
            this.txtConclusionDate = new System.Windows.Forms.TextBox();
            this.txtCode = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.tlpPreview.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.systemHRDataSet6)).BeginInit();
            this.pPreview.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlpPreview
            // 
            this.tlpPreview.ColumnCount = 1;
            this.tlpPreview.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpPreview.Controls.Add(this.pPreview, 0, 0);
            this.tlpPreview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpPreview.Location = new System.Drawing.Point(0, 0);
            this.tlpPreview.Name = "tlpPreview";
            this.tlpPreview.RowCount = 1;
            this.tlpPreview.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpPreview.Size = new System.Drawing.Size(395, 521);
            this.tlpPreview.TabIndex = 0;
            // 
            // systemHRDataSet6
            // 
            this.systemHRDataSet6.DataSetName = "SystemHRDataSet6";
            this.systemHRDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pPreview
            // 
            this.pPreview.Controls.Add(this.txtLastName);
            this.pPreview.Controls.Add(this.txtFirstName);
            this.pPreview.Controls.Add(this.txtCode);
            this.pPreview.Controls.Add(this.txtConclusionDate);
            this.pPreview.Controls.Add(this.txtDateFrom);
            this.pPreview.Controls.Add(this.txtDateTo);
            this.pPreview.Controls.Add(this.txtPosition);
            this.pPreview.Controls.Add(this.txtDepartament);
            this.pPreview.Controls.Add(this.txtSalary);
            this.pPreview.Controls.Add(this.txtCurrency);
            this.pPreview.Controls.Add(this.txtTypeContract);
            this.pPreview.Controls.Add(this.txtTypeRate);
            this.pPreview.Controls.Add(this.txtTerminationWay);
            this.pPreview.Controls.Add(this.lblTerminationWay);
            this.pPreview.Controls.Add(this.lblTypeContract);
            this.pPreview.Controls.Add(this.lblTypeRate);
            this.pPreview.Controls.Add(this.lblCurrency);
            this.pPreview.Controls.Add(this.lblSalary);
            this.pPreview.Controls.Add(this.lblDepartament);
            this.pPreview.Controls.Add(this.lblPosition);
            this.pPreview.Controls.Add(this.lblDateTo);
            this.pPreview.Controls.Add(this.lblDateFrom);
            this.pPreview.Controls.Add(this.lblConclusionDate);
            this.pPreview.Controls.Add(this.lblCode);
            this.pPreview.Controls.Add(this.lblFirstName);
            this.pPreview.Controls.Add(this.lblLastName);
            this.pPreview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pPreview.Location = new System.Drawing.Point(3, 3);
            this.pPreview.Name = "pPreview";
            this.pPreview.Size = new System.Drawing.Size(389, 515);
            this.pPreview.TabIndex = 0;
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblLastName.Location = new System.Drawing.Point(19, 18);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(63, 17);
            this.lblLastName.TabIndex = 0;
            this.lblLastName.Text = "Nazwisko";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblFirstName.Location = new System.Drawing.Point(19, 50);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(32, 17);
            this.lblFirstName.TabIndex = 1;
            this.lblFirstName.Text = "Imię";
            // 
            // lblCode
            // 
            this.lblCode.AutoSize = true;
            this.lblCode.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblCode.Location = new System.Drawing.Point(19, 83);
            this.lblCode.Name = "lblCode";
            this.lblCode.Size = new System.Drawing.Size(102, 17);
            this.lblCode.TabIndex = 2;
            this.lblCode.Text = "Kod pracownika";
            // 
            // lblConclusionDate
            // 
            this.lblConclusionDate.AutoSize = true;
            this.lblConclusionDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblConclusionDate.Location = new System.Drawing.Point(19, 116);
            this.lblConclusionDate.Name = "lblConclusionDate";
            this.lblConclusionDate.Size = new System.Drawing.Size(134, 17);
            this.lblConclusionDate.TabIndex = 3;
            this.lblConclusionDate.Text = "Data zawarcia umowy";
            // 
            // lblDateFrom
            // 
            this.lblDateFrom.AutoSize = true;
            this.lblDateFrom.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblDateFrom.Location = new System.Drawing.Point(19, 151);
            this.lblDateFrom.Name = "lblDateFrom";
            this.lblDateFrom.Size = new System.Drawing.Size(55, 17);
            this.lblDateFrom.TabIndex = 4;
            this.lblDateFrom.Text = "Data od";
            // 
            // lblDateTo
            // 
            this.lblDateTo.AutoSize = true;
            this.lblDateTo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblDateTo.Location = new System.Drawing.Point(19, 190);
            this.lblDateTo.Name = "lblDateTo";
            this.lblDateTo.Size = new System.Drawing.Size(55, 17);
            this.lblDateTo.TabIndex = 5;
            this.lblDateTo.Text = "Data do";
            // 
            // lblPosition
            // 
            this.lblPosition.AutoSize = true;
            this.lblPosition.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPosition.Location = new System.Drawing.Point(19, 231);
            this.lblPosition.Name = "lblPosition";
            this.lblPosition.Size = new System.Drawing.Size(73, 17);
            this.lblPosition.TabIndex = 6;
            this.lblPosition.Text = "Stanowisko";
            // 
            // lblDepartament
            // 
            this.lblDepartament.AutoSize = true;
            this.lblDepartament.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblDepartament.Location = new System.Drawing.Point(19, 268);
            this.lblDepartament.Name = "lblDepartament";
            this.lblDepartament.Size = new System.Drawing.Size(36, 17);
            this.lblDepartament.TabIndex = 7;
            this.lblDepartament.Text = "Dział";
            // 
            // lblSalary
            // 
            this.lblSalary.AutoSize = true;
            this.lblSalary.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblSalary.Location = new System.Drawing.Point(19, 308);
            this.lblSalary.Name = "lblSalary";
            this.lblSalary.Size = new System.Drawing.Size(99, 17);
            this.lblSalary.TabIndex = 8;
            this.lblSalary.Text = "Wynagrodzenie";
            // 
            // lblCurrency
            // 
            this.lblCurrency.AutoSize = true;
            this.lblCurrency.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblCurrency.Location = new System.Drawing.Point(19, 351);
            this.lblCurrency.Name = "lblCurrency";
            this.lblCurrency.Size = new System.Drawing.Size(47, 17);
            this.lblCurrency.TabIndex = 9;
            this.lblCurrency.Text = "Waluta";
            // 
            // lblTypeRate
            // 
            this.lblTypeRate.AutoSize = true;
            this.lblTypeRate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblTypeRate.Location = new System.Drawing.Point(19, 395);
            this.lblTypeRate.Name = "lblTypeRate";
            this.lblTypeRate.Size = new System.Drawing.Size(140, 17);
            this.lblTypeRate.TabIndex = 10;
            this.lblTypeRate.Text = "Rodzaj wynagrodzenia";
            // 
            // lblTypeContract
            // 
            this.lblTypeContract.AutoSize = true;
            this.lblTypeContract.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblTypeContract.Location = new System.Drawing.Point(19, 441);
            this.lblTypeContract.Name = "lblTypeContract";
            this.lblTypeContract.Size = new System.Drawing.Size(93, 17);
            this.lblTypeContract.TabIndex = 11;
            this.lblTypeContract.Text = "Rodzaj umowy";
            // 
            // lblTerminationWay
            // 
            this.lblTerminationWay.AutoSize = true;
            this.lblTerminationWay.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblTerminationWay.Location = new System.Drawing.Point(19, 481);
            this.lblTerminationWay.Name = "lblTerminationWay";
            this.lblTerminationWay.Size = new System.Drawing.Size(170, 17);
            this.lblTerminationWay.TabIndex = 12;
            this.lblTerminationWay.Text = "Sposób rozwiązania umowy";
            // 
            // txtTerminationWay
            // 
            this.txtTerminationWay.Location = new System.Drawing.Point(195, 473);
            this.txtTerminationWay.Name = "txtTerminationWay";
            this.txtTerminationWay.ReadOnly = true;
            this.txtTerminationWay.Size = new System.Drawing.Size(160, 25);
            this.txtTerminationWay.TabIndex = 13;
            // 
            // txtTypeRate
            // 
            this.txtTypeRate.Location = new System.Drawing.Point(195, 433);
            this.txtTypeRate.Name = "txtTypeRate";
            this.txtTypeRate.ReadOnly = true;
            this.txtTypeRate.Size = new System.Drawing.Size(160, 25);
            this.txtTypeRate.TabIndex = 14;
            // 
            // txtTypeContract
            // 
            this.txtTypeContract.Location = new System.Drawing.Point(195, 392);
            this.txtTypeContract.Name = "txtTypeContract";
            this.txtTypeContract.ReadOnly = true;
            this.txtTypeContract.Size = new System.Drawing.Size(160, 25);
            this.txtTypeContract.TabIndex = 15;
            // 
            // txtCurrency
            // 
            this.txtCurrency.Location = new System.Drawing.Point(195, 348);
            this.txtCurrency.Name = "txtCurrency";
            this.txtCurrency.ReadOnly = true;
            this.txtCurrency.Size = new System.Drawing.Size(160, 25);
            this.txtCurrency.TabIndex = 16;
            // 
            // txtSalary
            // 
            this.txtSalary.Location = new System.Drawing.Point(195, 308);
            this.txtSalary.Name = "txtSalary";
            this.txtSalary.ReadOnly = true;
            this.txtSalary.Size = new System.Drawing.Size(160, 25);
            this.txtSalary.TabIndex = 17;
            // 
            // txtDepartament
            // 
            this.txtDepartament.Location = new System.Drawing.Point(195, 265);
            this.txtDepartament.Name = "txtDepartament";
            this.txtDepartament.ReadOnly = true;
            this.txtDepartament.Size = new System.Drawing.Size(160, 25);
            this.txtDepartament.TabIndex = 18;
            // 
            // txtPosition
            // 
            this.txtPosition.Location = new System.Drawing.Point(195, 223);
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.ReadOnly = true;
            this.txtPosition.Size = new System.Drawing.Size(160, 25);
            this.txtPosition.TabIndex = 19;
            // 
            // txtDateTo
            // 
            this.txtDateTo.Location = new System.Drawing.Point(195, 187);
            this.txtDateTo.Name = "txtDateTo";
            this.txtDateTo.ReadOnly = true;
            this.txtDateTo.Size = new System.Drawing.Size(160, 25);
            this.txtDateTo.TabIndex = 20;
            // 
            // txtDateFrom
            // 
            this.txtDateFrom.Location = new System.Drawing.Point(195, 148);
            this.txtDateFrom.Name = "txtDateFrom";
            this.txtDateFrom.ReadOnly = true;
            this.txtDateFrom.Size = new System.Drawing.Size(160, 25);
            this.txtDateFrom.TabIndex = 21;
            // 
            // txtConclusionDate
            // 
            this.txtConclusionDate.Location = new System.Drawing.Point(195, 113);
            this.txtConclusionDate.Name = "txtConclusionDate";
            this.txtConclusionDate.ReadOnly = true;
            this.txtConclusionDate.Size = new System.Drawing.Size(160, 25);
            this.txtConclusionDate.TabIndex = 22;
            // 
            // txtCode
            // 
            this.txtCode.Location = new System.Drawing.Point(195, 83);
            this.txtCode.Name = "txtCode";
            this.txtCode.ReadOnly = true;
            this.txtCode.Size = new System.Drawing.Size(160, 25);
            this.txtCode.TabIndex = 23;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(195, 52);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.ReadOnly = true;
            this.txtFirstName.Size = new System.Drawing.Size(160, 25);
            this.txtFirstName.TabIndex = 24;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(195, 18);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.ReadOnly = true;
            this.txtLastName.Size = new System.Drawing.Size(160, 25);
            this.txtLastName.TabIndex = 25;
            // 
            // ContractPreviewForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 521);
            this.Controls.Add(this.tlpPreview);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Name = "ContractPreviewForm";
            this.Text = "Podgląd";
            this.tlpPreview.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.systemHRDataSet6)).EndInit();
            this.pPreview.ResumeLayout(false);
            this.pPreview.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpPreview;
        private SystemHRDataSet6 systemHRDataSet6;
        private System.Windows.Forms.Panel pPreview;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.TextBox txtConclusionDate;
        private System.Windows.Forms.TextBox txtDateFrom;
        private System.Windows.Forms.TextBox txtDateTo;
        private System.Windows.Forms.TextBox txtPosition;
        private System.Windows.Forms.TextBox txtDepartament;
        private System.Windows.Forms.TextBox txtSalary;
        private System.Windows.Forms.TextBox txtCurrency;
        private System.Windows.Forms.TextBox txtTypeContract;
        private System.Windows.Forms.TextBox txtTypeRate;
        private System.Windows.Forms.TextBox txtTerminationWay;
        private System.Windows.Forms.Label lblTerminationWay;
        private System.Windows.Forms.Label lblTypeContract;
        private System.Windows.Forms.Label lblTypeRate;
        private System.Windows.Forms.Label lblCurrency;
        private System.Windows.Forms.Label lblSalary;
        private System.Windows.Forms.Label lblDepartament;
        private System.Windows.Forms.Label lblPosition;
        private System.Windows.Forms.Label lblDateTo;
        private System.Windows.Forms.Label lblDateFrom;
        private System.Windows.Forms.Label lblConclusionDate;
        private System.Windows.Forms.Label lblCode;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblLastName;
    }
}