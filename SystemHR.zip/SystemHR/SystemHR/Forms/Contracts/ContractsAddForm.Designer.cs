﻿namespace SystemHR.UserInterface.Forms.Contracts
{
    partial class ContractsAddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gbEmployee = new System.Windows.Forms.GroupBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblContract = new System.Windows.Forms.Label();
            this.gbContract = new System.Windows.Forms.GroupBox();
            this.txtDepartament = new System.Windows.Forms.TextBox();
            this.txtPosition = new System.Windows.Forms.TextBox();
            this.dtpDateTo = new System.Windows.Forms.DateTimePicker();
            this.dtpDateForm = new System.Windows.Forms.DateTimePicker();
            this.dtpConclusionDate = new System.Windows.Forms.DateTimePicker();
            this.cbTypeContract = new System.Windows.Forms.ComboBox();
            this.bsTypeContract = new System.Windows.Forms.BindingSource(this.components);
            this.lblDepartament = new System.Windows.Forms.Label();
            this.lblPosition = new System.Windows.Forms.Label();
            this.lblDateTo = new System.Windows.Forms.Label();
            this.lblDateFrom = new System.Windows.Forms.Label();
            this.lblConclusionDate = new System.Windows.Forms.Label();
            this.lblTypeContract = new System.Windows.Forms.Label();
            this.gbSalary = new System.Windows.Forms.GroupBox();
            this.cbTypeRate = new System.Windows.Forms.ComboBox();
            this.bsTypeRate = new System.Windows.Forms.BindingSource(this.components);
            this.cbCurrency = new System.Windows.Forms.ComboBox();
            this.bsCurrency = new System.Windows.Forms.BindingSource(this.components);
            this.nudAmount = new System.Windows.Forms.NumericUpDown();
            this.lblTypeRate = new System.Windows.Forms.Label();
            this.lblCurrency = new System.Windows.Forms.Label();
            this.lblAmount = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.epFirstName = new System.Windows.Forms.ErrorProvider(this.components);
            this.epLastName = new System.Windows.Forms.ErrorProvider(this.components);
            this.lblCode = new System.Windows.Forms.Label();
            this.txtCode = new System.Windows.Forms.TextBox();
            this.gbEmployee.SuspendLayout();
            this.gbContract.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsTypeContract)).BeginInit();
            this.gbSalary.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsTypeRate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCurrency)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAmount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.epFirstName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.epLastName)).BeginInit();
            this.SuspendLayout();
            // 
            // gbEmployee
            // 
            this.gbEmployee.Controls.Add(this.txtCode);
            this.gbEmployee.Controls.Add(this.lblCode);
            this.gbEmployee.Controls.Add(this.txtLastName);
            this.gbEmployee.Controls.Add(this.txtFirstName);
            this.gbEmployee.Controls.Add(this.lblLastName);
            this.gbEmployee.Controls.Add(this.lblFirstName);
            this.gbEmployee.Location = new System.Drawing.Point(12, 42);
            this.gbEmployee.Name = "gbEmployee";
            this.gbEmployee.Size = new System.Drawing.Size(299, 132);
            this.gbEmployee.TabIndex = 0;
            this.gbEmployee.TabStop = false;
            this.gbEmployee.Text = "Pracownik";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(115, 63);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(156, 20);
            this.txtLastName.TabIndex = 3;
            this.txtLastName.TextChanged += new System.EventHandler(this.txtLastName_TextChanged);
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(115, 25);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(156, 20);
            this.txtFirstName.TabIndex = 2;
            this.txtFirstName.TextChanged += new System.EventHandler(this.txtFirstName_TextChanged);
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblLastName.Location = new System.Drawing.Point(6, 66);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(63, 17);
            this.lblLastName.TabIndex = 1;
            this.lblLastName.Text = "Nazwisko";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblFirstName.Location = new System.Drawing.Point(6, 28);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(32, 17);
            this.lblFirstName.TabIndex = 0;
            this.lblFirstName.Text = "Imię";
            // 
            // lblContract
            // 
            this.lblContract.AutoSize = true;
            this.lblContract.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblContract.Location = new System.Drawing.Point(17, 9);
            this.lblContract.Name = "lblContract";
            this.lblContract.Size = new System.Drawing.Size(83, 30);
            this.lblContract.TabIndex = 1;
            this.lblContract.Text = "Umowa";
            // 
            // gbContract
            // 
            this.gbContract.Controls.Add(this.txtDepartament);
            this.gbContract.Controls.Add(this.txtPosition);
            this.gbContract.Controls.Add(this.dtpDateTo);
            this.gbContract.Controls.Add(this.dtpDateForm);
            this.gbContract.Controls.Add(this.dtpConclusionDate);
            this.gbContract.Controls.Add(this.cbTypeContract);
            this.gbContract.Controls.Add(this.lblDepartament);
            this.gbContract.Controls.Add(this.lblPosition);
            this.gbContract.Controls.Add(this.lblDateTo);
            this.gbContract.Controls.Add(this.lblDateFrom);
            this.gbContract.Controls.Add(this.lblConclusionDate);
            this.gbContract.Controls.Add(this.lblTypeContract);
            this.gbContract.Location = new System.Drawing.Point(12, 174);
            this.gbContract.Name = "gbContract";
            this.gbContract.Size = new System.Drawing.Size(299, 208);
            this.gbContract.TabIndex = 2;
            this.gbContract.TabStop = false;
            this.gbContract.Text = "Umowa";
            // 
            // txtDepartament
            // 
            this.txtDepartament.Location = new System.Drawing.Point(121, 173);
            this.txtDepartament.Name = "txtDepartament";
            this.txtDepartament.Size = new System.Drawing.Size(150, 20);
            this.txtDepartament.TabIndex = 11;
            // 
            // txtPosition
            // 
            this.txtPosition.Location = new System.Drawing.Point(121, 143);
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.Size = new System.Drawing.Size(150, 20);
            this.txtPosition.TabIndex = 10;
            // 
            // dtpDateTo
            // 
            this.dtpDateTo.CustomFormat = " ";
            this.dtpDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDateTo.Location = new System.Drawing.Point(121, 110);
            this.dtpDateTo.Name = "dtpDateTo";
            this.dtpDateTo.Size = new System.Drawing.Size(150, 20);
            this.dtpDateTo.TabIndex = 9;
            this.dtpDateTo.ValueChanged += new System.EventHandler(this.dtp_ValueChanged);
            // 
            // dtpDateForm
            // 
            this.dtpDateForm.CustomFormat = " ";
            this.dtpDateForm.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDateForm.Location = new System.Drawing.Point(121, 78);
            this.dtpDateForm.Name = "dtpDateForm";
            this.dtpDateForm.Size = new System.Drawing.Size(150, 20);
            this.dtpDateForm.TabIndex = 8;
            this.dtpDateForm.ValueChanged += new System.EventHandler(this.dtp_ValueChanged);
            // 
            // dtpConclusionDate
            // 
            this.dtpConclusionDate.CustomFormat = " ";
            this.dtpConclusionDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpConclusionDate.Location = new System.Drawing.Point(121, 49);
            this.dtpConclusionDate.Name = "dtpConclusionDate";
            this.dtpConclusionDate.Size = new System.Drawing.Size(150, 20);
            this.dtpConclusionDate.TabIndex = 7;
            this.dtpConclusionDate.ValueChanged += new System.EventHandler(this.dtp_ValueChanged);
            // 
            // cbTypeContract
            // 
            this.cbTypeContract.DataSource = this.bsTypeContract;
            this.cbTypeContract.FormattingEnabled = true;
            this.cbTypeContract.Location = new System.Drawing.Point(121, 20);
            this.cbTypeContract.Name = "cbTypeContract";
            this.cbTypeContract.Size = new System.Drawing.Size(150, 21);
            this.cbTypeContract.TabIndex = 6;
            // 
            // lblDepartament
            // 
            this.lblDepartament.AutoSize = true;
            this.lblDepartament.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblDepartament.Location = new System.Drawing.Point(6, 176);
            this.lblDepartament.Name = "lblDepartament";
            this.lblDepartament.Size = new System.Drawing.Size(36, 17);
            this.lblDepartament.TabIndex = 5;
            this.lblDepartament.Text = "Dział";
            // 
            // lblPosition
            // 
            this.lblPosition.AutoSize = true;
            this.lblPosition.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPosition.Location = new System.Drawing.Point(7, 146);
            this.lblPosition.Name = "lblPosition";
            this.lblPosition.Size = new System.Drawing.Size(73, 17);
            this.lblPosition.TabIndex = 4;
            this.lblPosition.Text = "Stanowisko";
            // 
            // lblDateTo
            // 
            this.lblDateTo.AutoSize = true;
            this.lblDateTo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblDateTo.Location = new System.Drawing.Point(7, 113);
            this.lblDateTo.Name = "lblDateTo";
            this.lblDateTo.Size = new System.Drawing.Size(55, 17);
            this.lblDateTo.TabIndex = 3;
            this.lblDateTo.Text = "Data do";
            // 
            // lblDateFrom
            // 
            this.lblDateFrom.AutoSize = true;
            this.lblDateFrom.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblDateFrom.Location = new System.Drawing.Point(7, 78);
            this.lblDateFrom.Name = "lblDateFrom";
            this.lblDateFrom.Size = new System.Drawing.Size(55, 17);
            this.lblDateFrom.TabIndex = 2;
            this.lblDateFrom.Text = "Data od";
            // 
            // lblConclusionDate
            // 
            this.lblConclusionDate.AutoSize = true;
            this.lblConclusionDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblConclusionDate.Location = new System.Drawing.Point(7, 49);
            this.lblConclusionDate.Name = "lblConclusionDate";
            this.lblConclusionDate.Size = new System.Drawing.Size(89, 17);
            this.lblConclusionDate.TabIndex = 1;
            this.lblConclusionDate.Text = "Data zawarcia";
            // 
            // lblTypeContract
            // 
            this.lblTypeContract.AutoSize = true;
            this.lblTypeContract.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblTypeContract.Location = new System.Drawing.Point(7, 20);
            this.lblTypeContract.Name = "lblTypeContract";
            this.lblTypeContract.Size = new System.Drawing.Size(48, 17);
            this.lblTypeContract.TabIndex = 0;
            this.lblTypeContract.Text = "Rodzaj";
            // 
            // gbSalary
            // 
            this.gbSalary.Controls.Add(this.cbTypeRate);
            this.gbSalary.Controls.Add(this.cbCurrency);
            this.gbSalary.Controls.Add(this.nudAmount);
            this.gbSalary.Controls.Add(this.lblTypeRate);
            this.gbSalary.Controls.Add(this.lblCurrency);
            this.gbSalary.Controls.Add(this.lblAmount);
            this.gbSalary.Location = new System.Drawing.Point(12, 389);
            this.gbSalary.Name = "gbSalary";
            this.gbSalary.Size = new System.Drawing.Size(299, 118);
            this.gbSalary.TabIndex = 3;
            this.gbSalary.TabStop = false;
            this.gbSalary.Text = "Wynagrodzenie";
            // 
            // cbTypeRate
            // 
            this.cbTypeRate.DataSource = this.bsTypeRate;
            this.cbTypeRate.FormattingEnabled = true;
            this.cbTypeRate.Location = new System.Drawing.Point(121, 87);
            this.cbTypeRate.Name = "cbTypeRate";
            this.cbTypeRate.Size = new System.Drawing.Size(150, 21);
            this.cbTypeRate.TabIndex = 5;
            // 
            // cbCurrency
            // 
            this.cbCurrency.DataSource = this.bsCurrency;
            this.cbCurrency.FormattingEnabled = true;
            this.cbCurrency.Location = new System.Drawing.Point(121, 52);
            this.cbCurrency.Name = "cbCurrency";
            this.cbCurrency.Size = new System.Drawing.Size(150, 21);
            this.cbCurrency.TabIndex = 4;
            // 
            // nudAmount
            // 
            this.nudAmount.Location = new System.Drawing.Point(121, 20);
            this.nudAmount.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nudAmount.Name = "nudAmount";
            this.nudAmount.Size = new System.Drawing.Size(150, 20);
            this.nudAmount.TabIndex = 3;
            // 
            // lblTypeRate
            // 
            this.lblTypeRate.AutoSize = true;
            this.lblTypeRate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblTypeRate.Location = new System.Drawing.Point(6, 87);
            this.lblTypeRate.Name = "lblTypeRate";
            this.lblTypeRate.Size = new System.Drawing.Size(87, 17);
            this.lblTypeRate.TabIndex = 2;
            this.lblTypeRate.Text = "Rodzaj stawki";
            // 
            // lblCurrency
            // 
            this.lblCurrency.AutoSize = true;
            this.lblCurrency.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblCurrency.Location = new System.Drawing.Point(7, 52);
            this.lblCurrency.Name = "lblCurrency";
            this.lblCurrency.Size = new System.Drawing.Size(47, 17);
            this.lblCurrency.TabIndex = 1;
            this.lblCurrency.Text = "Waluta";
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblAmount.Location = new System.Drawing.Point(7, 20);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(44, 17);
            this.lblAmount.TabIndex = 0;
            this.lblAmount.Text = "Kwota";
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnCancel.Location = new System.Drawing.Point(162, 520);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(127, 48);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Anuluj";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnSave.Location = new System.Drawing.Point(29, 520);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(127, 48);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Zapisz";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // epFirstName
            // 
            this.epFirstName.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.epFirstName.ContainerControl = this;
            // 
            // epLastName
            // 
            this.epLastName.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.epLastName.ContainerControl = this;
            // 
            // lblCode
            // 
            this.lblCode.AutoSize = true;
            this.lblCode.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblCode.Location = new System.Drawing.Point(7, 106);
            this.lblCode.Name = "lblCode";
            this.lblCode.Size = new System.Drawing.Size(102, 17);
            this.lblCode.TabIndex = 4;
            this.lblCode.Text = "Kod pracownika";
            // 
            // txtCode
            // 
            this.txtCode.Location = new System.Drawing.Point(115, 103);
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(156, 20);
            this.txtCode.TabIndex = 5;
            // 
            // ContractsAddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(323, 580);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.gbSalary);
            this.Controls.Add(this.gbContract);
            this.Controls.Add(this.lblContract);
            this.Controls.Add(this.gbEmployee);
            this.Name = "ContractsAddForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dodaj nowy kontrakt";
            this.gbEmployee.ResumeLayout(false);
            this.gbEmployee.PerformLayout();
            this.gbContract.ResumeLayout(false);
            this.gbContract.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsTypeContract)).EndInit();
            this.gbSalary.ResumeLayout(false);
            this.gbSalary.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsTypeRate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCurrency)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAmount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.epFirstName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.epLastName)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbEmployee;
        private System.Windows.Forms.Label lblContract;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.GroupBox gbContract;
        private System.Windows.Forms.ComboBox cbTypeContract;
        private System.Windows.Forms.Label lblDepartament;
        private System.Windows.Forms.Label lblPosition;
        private System.Windows.Forms.Label lblDateTo;
        private System.Windows.Forms.Label lblDateFrom;
        private System.Windows.Forms.Label lblConclusionDate;
        private System.Windows.Forms.Label lblTypeContract;
        private System.Windows.Forms.TextBox txtDepartament;
        private System.Windows.Forms.TextBox txtPosition;
        private System.Windows.Forms.DateTimePicker dtpDateTo;
        private System.Windows.Forms.DateTimePicker dtpDateForm;
        private System.Windows.Forms.DateTimePicker dtpConclusionDate;
        private System.Windows.Forms.GroupBox gbSalary;
        private System.Windows.Forms.Label lblTypeRate;
        private System.Windows.Forms.Label lblCurrency;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.ComboBox cbTypeRate;
        private System.Windows.Forms.ComboBox cbCurrency;
        private System.Windows.Forms.NumericUpDown nudAmount;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.BindingSource bsTypeContract;
        private System.Windows.Forms.BindingSource bsTypeRate;
        private System.Windows.Forms.BindingSource bsCurrency;
        private System.Windows.Forms.ErrorProvider epFirstName;
        private System.Windows.Forms.ErrorProvider epLastName;
        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.Label lblCode;
    }
}