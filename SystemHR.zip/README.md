# System HR

Application for human resources management.