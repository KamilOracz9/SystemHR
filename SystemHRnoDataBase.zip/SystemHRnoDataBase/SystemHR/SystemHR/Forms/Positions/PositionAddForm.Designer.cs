﻿namespace SystemHR.UserInterface.Forms.Positions
{
    partial class PositionAddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblStanowisko = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblMaxSalary = new System.Windows.Forms.Label();
            this.lblMinSalary = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.nudMaxSalary = new System.Windows.Forms.NumericUpDown();
            this.nudMinSalary = new System.Windows.Forms.NumericUpDown();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.epName = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.nudMaxSalary)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMinSalary)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.epName)).BeginInit();
            this.SuspendLayout();
            // 
            // lblStanowisko
            // 
            this.lblStanowisko.AutoSize = true;
            this.lblStanowisko.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblStanowisko.Location = new System.Drawing.Point(24, 27);
            this.lblStanowisko.Name = "lblStanowisko";
            this.lblStanowisko.Size = new System.Drawing.Size(116, 30);
            this.lblStanowisko.TabIndex = 0;
            this.lblStanowisko.Text = "Stanowisko";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblName.Location = new System.Drawing.Point(29, 101);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(47, 17);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Nazwa";
            // 
            // lblMaxSalary
            // 
            this.lblMaxSalary.AutoSize = true;
            this.lblMaxSalary.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblMaxSalary.Location = new System.Drawing.Point(29, 144);
            this.lblMaxSalary.Name = "lblMaxSalary";
            this.lblMaxSalary.Size = new System.Drawing.Size(128, 17);
            this.lblMaxSalary.TabIndex = 2;
            this.lblMaxSalary.Text = "Max. wynagrodzenie";
            // 
            // lblMinSalary
            // 
            this.lblMinSalary.AutoSize = true;
            this.lblMinSalary.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblMinSalary.Location = new System.Drawing.Point(29, 185);
            this.lblMinSalary.Name = "lblMinSalary";
            this.lblMinSalary.Size = new System.Drawing.Size(125, 17);
            this.lblMinSalary.TabIndex = 3;
            this.lblMinSalary.Text = "Min. wynagrodzenie";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(181, 101);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(185, 20);
            this.txtName.TabIndex = 4;
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // nudMaxSalary
            // 
            this.nudMaxSalary.Location = new System.Drawing.Point(181, 144);
            this.nudMaxSalary.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nudMaxSalary.Name = "nudMaxSalary";
            this.nudMaxSalary.Size = new System.Drawing.Size(185, 20);
            this.nudMaxSalary.TabIndex = 5;
            // 
            // nudMinSalary
            // 
            this.nudMinSalary.Location = new System.Drawing.Point(181, 186);
            this.nudMinSalary.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nudMinSalary.Name = "nudMinSalary";
            this.nudMinSalary.Size = new System.Drawing.Size(185, 20);
            this.nudMinSalary.TabIndex = 6;
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnCancel.Location = new System.Drawing.Point(239, 227);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(127, 48);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Anuluj";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnSave.Location = new System.Drawing.Point(106, 227);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(127, 48);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Zapisz";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // epName
            // 
            this.epName.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.epName.ContainerControl = this;
            // 
            // PositionAddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 287);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.nudMinSalary);
            this.Controls.Add(this.nudMaxSalary);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblMinSalary);
            this.Controls.Add(this.lblMaxSalary);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblStanowisko);
            this.Name = "PositionAddForm";
            this.Text = "Dodaj stanowisko";
            ((System.ComponentModel.ISupportInitialize)(this.nudMaxSalary)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMinSalary)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.epName)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblStanowisko;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblMaxSalary;
        private System.Windows.Forms.Label lblMinSalary;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.NumericUpDown nudMaxSalary;
        private System.Windows.Forms.NumericUpDown nudMinSalary;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ErrorProvider epName;
    }
}