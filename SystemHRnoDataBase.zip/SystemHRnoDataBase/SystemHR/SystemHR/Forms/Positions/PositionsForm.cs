﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Classes;

namespace SystemHR.UserInterface.Forms.Positions
{
    public partial class PositionsForm : Form
    {
        #region fields
        public static bool tabIsOpen = false;
        public static IList<PositionModel> fakePositions;
        #endregion
        #region constructors
        public PositionsForm()
        {
            InitializeComponent();
            fakePositions = GetFakePositions();
            PreparePositionsData();
        }
        #endregion
        #region private methods
        private void PreparePositionsData()
        {
            bsPosition.DataSource = new BindingList<PositionModel>(fakePositions);
            dgvPositions.DataSource = bsPosition;
        }

        private IList<PositionModel> GetFakePositions()
        {
            IList<PositionModel> fakePositionModel = new List<PositionModel>()
            {
                new PositionModel()
                {
                    Id=1,
                    Name = "Kierownik",
                    MaxSalary = 10000,
                    MinSalary = 5000
                }
            };
            return fakePositionModel;
        }
        #endregion
        #region events
        private void btnCreate_Click(object sender, EventArgs e)
        {
            PositionAddForm frm = new PositionAddForm();
            frm.ReloadPositions += (s, ea) =>
            {
                PositionEventArgs eventArgs = ea as PositionEventArgs;
                if (eventArgs != null)
                {
                    PositionModel position = eventArgs.position;
                    bsPosition.Add(position);
                    dgvPositions.ClearSelection();
                    dgvPositions.Rows[dgvPositions.Rows.Count - 1].Selected = true;
                }
            };
            frm.ShowDialog();
        }
        private void btnModify_Click(object sender, EventArgs e)
        {
            int positionId = Convert.ToInt32(dgvPositions.CurrentRow.Cells["colId"].Value);
            int selectedRowIndex = dgvPositions.CurrentRow.Index;
            PositionEditForm frm = new PositionEditForm(positionId);
            frm.ReloadPositions += (s, ea) =>
            {
                PositionEventArgs eventArgs = ea as PositionEventArgs;
                if(eventArgs != null)
                {
                    PositionModel position = eventArgs.position;
                    bsPosition[selectedRowIndex] = position;
                }
            };
            frm.ShowDialog();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            dgvPositions.Refresh();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            int positionId = Convert.ToInt32(dgvPositions.CurrentRow.Cells["colId"].Value);
            int selectedRowIndex = dgvPositions.CurrentRow.Index;
            PositionModel position = fakePositions.Where(x => x.Id == positionId).FirstOrDefault();
            if (position != null)
            {
                bsPosition.Remove(position);
                if (dgvPositions.Rows.Count > 0)
                {
                    dgvPositions.ClearSelection();
                    dgvPositions.Rows[dgvPositions.Rows.Count - 1].Selected = true;
                }
            }
        }
        #endregion
    }
}