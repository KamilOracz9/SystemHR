﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Classes;
using SystemHR.DataAccessLayer.Models;
using SystemHR.UserInterface.Forms.Base;

namespace SystemHR.UserInterface.Forms.Positions
{
    public partial class PositionAddForm : BaseForm
    {
        #region fields
        public EventHandler ReloadPositions;
        #endregion
        #region constructors
        public PositionAddForm()
        {
            InitializeComponent();
            ValidationControls();
        }
        #endregion
        #region private methods
        private void txtName_TextChanged(object sender, EventArgs e)
        {
            ValidationControls();
        }
        private bool ValidationForm()
        {
            StringBuilder sbErrorMessage = new StringBuilder();
            string nameErrorMessage = epName.GetError(txtName);
            if (!string.IsNullOrEmpty(nameErrorMessage))
            {
                sbErrorMessage.Append(nameErrorMessage);
            }
            if (sbErrorMessage.Length > 0)
            {
                MessageBox.Show(
                    sbErrorMessage.ToString(),
                    "Dodawanie stanowsika",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        #endregion
        #region events
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidationForm())
            {
                PositionModel position = new PositionModel()
                {
                    Name = txtName.Text,
                    MaxSalary = nudMaxSalary.Value,
                    MinSalary = nudMinSalary.Value
                };
                ReloadPositions?.Invoke(btnSave, new PositionEventArgs(position));
                Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void ValidationControls()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                epName.SetError(txtName, "Pole nazwa jest wymagane!");
            }
            else
            {
                epName.Clear();
            }
        }
        #endregion
    }
}
