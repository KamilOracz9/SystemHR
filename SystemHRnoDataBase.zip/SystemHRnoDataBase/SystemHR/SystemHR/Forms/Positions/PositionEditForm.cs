﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.UserInterface.Forms.Base;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Classes;

namespace SystemHR.UserInterface.Forms.Positions
{
    public partial class PositionEditForm : BaseForm
    {
        #region fields
        private PositionModel position;
        public EventHandler ReloadPositions;
        #endregion
        #region constructors
        public PositionEditForm(int positionId)
        {
            InitializeComponent();
            position = (PositionModel)GetFakePositions(positionId);
            PreparePositionData(position);
            ValidationControls();
        }
        #endregion
        #region private methods
        private void PreparePositionData(PositionModel position)
        {
            txtName.Text = position.Name;
            nudMaxSalary.Value = position.MaxSalary;
            nudMinSalary.Value = position.MinSalary;
        }

        private PositionModel GetFakePositions(int positionId)
        {
            IList<PositionModel> fakePositionsModel = new List<PositionModel>()
            {
                new PositionModel()
                {
                    Id=1,
                    Name = "Kierownik",
                    MaxSalary = 10000,
                    MinSalary = 5000
                }
            };
            PositionModel fakePositionModel = fakePositionsModel.Where(x => x.Id == positionId).FirstOrDefault();
            return fakePositionModel;
        }
        private bool ValidationForm()
        {
            StringBuilder sbErrorMessage = new StringBuilder();
            string nameErrorMessage = epName.GetError(txtName);
            if (!string.IsNullOrEmpty(nameErrorMessage))
            {
                sbErrorMessage.Append(nameErrorMessage);
            }
            if (sbErrorMessage.Length > 0)
            {
                MessageBox.Show(
                    sbErrorMessage.ToString(),
                    "Modyfikuj stanowisko",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            ValidationControls();
        }
        #endregion
        #region events
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidationForm())
            {
                position.Name = txtName.Text;
                position.MaxSalary = nudMaxSalary.Value;
                position.MinSalary = nudMinSalary.Value;
            }
            ReloadPositions?.Invoke(btnSave, new PositionEventArgs(position));
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void ValidationControls()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                epName.SetError(txtName, "Pole nazwa jest wymagane");
            }
            else epName.Clear();
        }
        #endregion 
    }
}
