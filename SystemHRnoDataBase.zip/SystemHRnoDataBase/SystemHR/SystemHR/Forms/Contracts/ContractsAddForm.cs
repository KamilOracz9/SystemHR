﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Models.Dictionaries;
using SystemHR.UserInterface.Extensions;
using SystemHR.UserInterface.Helpers;
using SystemHR.DataAccessLayer.Classes;

namespace SystemHR.UserInterface.Forms.Contracts
{
    public partial class ContractsAddForm : Form
    {
        #region fields
        public EventHandler ReloadContracts;
        #endregion
        #region constructor
        public ContractsAddForm()
        {
            InitializeComponent();
            InitializeData();
            ValidateControls();
        }
        #endregion
        #region private methods
        private void ValidateControls()
        {
            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                epFirstName.SetError(txtFirstName, "Pole imię jest wymagane!");
            }
            else
            {
                epFirstName.Clear();
            }
            if (string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                epLastName.SetError(txtLastName, "Pole nazwisko jest wymagane!");
            }
            else
            {
                epLastName.Clear();
            }
        }

        private void InitializeData()
        {
            IList<TypeContract> contracts = new List<TypeContract>()
            {
                new TypeContract("Umowa o pracę"),
                new TypeContract("Umowa zlecenie"),
                new TypeContract("Umowa o dzieło"),
                new TypeContract(string.Empty)
            };
            bsTypeContract.DataSource = contracts;
            cbTypeContract.Text = string.Empty;
            IList<Currency> currencies = new List<Currency>()
            {
                new Currency("Złoty"),
                new Currency("Dolar"),
                new Currency("Euro"),
                new Currency(string.Empty)
            };
            bsCurrency.DataSource = currencies;
            cbCurrency.Text = string.Empty;
            IList<TypeRate> typeRates = new List<TypeRate>()
            {
                new TypeRate("Miesięczna"),
                new TypeRate("Tygodniowa"),
                new TypeRate("Dzienna"),
                new TypeRate("Godzinowa"),
                new TypeRate(string.Empty)
            };
            bsTypeRate.DataSource = typeRates;
            cbTypeRate.Text = string.Empty;
        }
        private bool ValidateForm()
        {
            StringBuilder sbErrorMessage = new StringBuilder();
            string lastNameErrorMessage = epLastName.GetError(txtLastName);
            if (!string.IsNullOrEmpty(lastNameErrorMessage))
            {
                sbErrorMessage.Append(lastNameErrorMessage);
            }
            string firstNameErrorMessage = epFirstName.GetError(txtFirstName);
            if (!string.IsNullOrEmpty(firstNameErrorMessage))
            {
                sbErrorMessage.Append(firstNameErrorMessage);
            }
            if (sbErrorMessage.Length > 0)
            {
                MessageBox.Show(
                    sbErrorMessage.ToString(),
                    "Dodawanie kontraktu",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        #endregion
        #region events
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateForm())
            {
                ContractModel contract = new ContractModel()
                {
                    LastName = txtLastName.Text,
                    FirstName = txtFirstName.Text,
                    TypeContract = new TypeContract(cbTypeContract.Text),
                    ConclusionDate = dtpConclusionDate.Value,
                    DateFrom = dtpDateForm.Value,
                    DateTo = dtpDateTo.Value,
                    Position = new Position(txtPosition.Text),
                    Departament = new Departament(txtDepartament.Text),
                    Salary = nudAmount.Value,
                    Currency = new Currency(cbCurrency.Text),
                    TypeRate = new TypeRate(cbTypeRate.Text),
                    TerminationWay = new TerminationWay(string.Empty)
                };
                contract.Id = 2;
                contract.Code = 2;
                ReloadContracts?.Invoke(btnSave, new ContractEventArgs(contract));
                Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void dtp_ValueChanged(object sender, EventArgs e)
        {
            DateTimePicker dtp = sender as DateTimePicker;
            dtp.DateTimePickerValueChanged();
        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {
            ValidateControls();
        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {
            ValidateControls();
        }
        #endregion
    }
}
