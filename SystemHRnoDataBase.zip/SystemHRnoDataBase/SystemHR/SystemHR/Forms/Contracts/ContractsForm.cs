﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Classes;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Models.Dictionaries;
using SystemHR.DataAccessLayer.ViewModels;
using SystemHR.UserInterface.Helpers;

namespace SystemHR.UserInterface.Forms.Contracts
{
    public partial class ContractsForm : Form
    {
        #region fields
        public static bool tabIsOpen = false;
        public static IList<ContractViewModel> fakeContracts;
        #endregion
        #region constructors
        public ContractsForm()
        {
            InitializeComponent();
            fakeContracts = GetFakeContract();
            PrepareContractsData();
        }
        #endregion
        #region private methods
        private void PrepareContractsData()
        {
            bsContracts.DataSource = new BindingList<ContractViewModel>(fakeContracts);
            dgvContracts.DataSource = bsContracts;
        }

        private IList<ContractViewModel> GetFakeContract()
        {
            IList<ContractModel> fakeContractsModel = new List<ContractModel>()
            {
                new ContractModel()
                {
                    Id = 1,
                    Code = 1,
                    TypeContract = new TypeContract("Umowa o prace"),
                    ConclusionDate = new DateTime(2018,04,08),
                    DateFrom = new DateTime(2018,04,08),
                    DateTo = new DateTime(2019,04,08),
                    Position = new Position("Kierownik"),
                    Departament = new Departament("Pordukcja"),
                    Salary = 10000,
                    Currency = new Currency("Złoty"),
                    TypeRate = new TypeRate("Miesięczna"),
                    TerminationWay = new TerminationWay(string.Empty),
                    LastName = "Stonoga",
                    FirstName = "Zbigniew"
                }
            };
            return MappingHelper.MapContractModelToContractViewModel(fakeContractsModel);
        }
        #endregion
        #region events
        private void btnCreate_Click(object sender, EventArgs e)
        {
            ContractsAddForm frm = new ContractsAddForm();
            frm.ReloadContracts += (s, ea) =>
            {
                ContractEventArgs eventArgs = ea as ContractEventArgs;
                if (eventArgs != null)
                {
                    ContractViewModel contract = MappingHelper.MapContractModelToContractViewModel(eventArgs.contract);
                    bsContracts.Add(contract);
                    dgvContracts.ClearSelection();
                    dgvContracts.Rows[dgvContracts.Rows.Count - 1].Selected = true;
                }
            };
            frm.ShowDialog();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            dgvContracts.Refresh();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            int contractId = Convert.ToInt32(dgvContracts.CurrentRow.Cells["colId"].Value);
            int selectedRowIndex = dgvContracts.CurrentRow.Index;

            ContractViewModel contract = fakeContracts.Where(x => x.Id == contractId).FirstOrDefault();
            if (contract != null)
            {
                bsContracts.Remove(contract);
                if (dgvContracts.Rows.Count > 0)
                {
                    dgvContracts.ClearSelection();
                    dgvContracts.Rows[dgvContracts.Rows.Count - 1].Selected = true;
                }
            }
        }
        #endregion
    }
}
