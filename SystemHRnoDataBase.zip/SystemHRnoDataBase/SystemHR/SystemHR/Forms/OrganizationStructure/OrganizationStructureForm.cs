﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.ViewModels;

namespace SystemHR.UserInterface.Forms.OrganizationStructure
{
    public partial class OrganizationStructureForm : Form
    {
        #region fields
        public static bool tabIsOpen = false;
        private IList<OrganizationStructureViewModel> organizationStructures;
        #endregion
        #region constructors
        public OrganizationStructureForm()
        {
            InitializeComponent();
            organizationStructures = GetFakeOrganizationStructures();
            PrepareOrganizationStructureData();
        }
        #endregion
        #region private methods
        private void PrepareOrganizationStructureData()
        {
            bsOrganizationStructure.DataSource = organizationStructures;
            dgvOrganizationStructure.DataSource = bsOrganizationStructure;
        }

        private IList<OrganizationStructureViewModel> GetFakeOrganizationStructures()
        {
            IList<OrganizationStructureViewModel> organizationStructures = new List<OrganizationStructureViewModel>()
            {
                new OrganizationStructureViewModel()
                {
                    DepartamentName = "Produkcja",
                    DepartamentManager = "Stonoga Zbigniew",
                    Localization = "Pierwsze piętro"
                }
            };
            return organizationStructures;
        }
        #endregion
    }
}
