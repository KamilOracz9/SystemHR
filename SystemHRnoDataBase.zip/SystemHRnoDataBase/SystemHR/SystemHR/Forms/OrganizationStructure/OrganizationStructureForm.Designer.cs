﻿namespace SystemHR.UserInterface.Forms.OrganizationStructure
{
    partial class OrganizationStructureForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tlpOrganizationStructure = new System.Windows.Forms.TableLayoutPanel();
            this.dgvOrganizationStructure = new System.Windows.Forms.DataGridView();
            this.bsOrganizationStructure = new System.Windows.Forms.BindingSource(this.components);
            this.colDepartamentName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDepartamentManager = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLocalization = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tlpOrganizationStructure.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrganizationStructure)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsOrganizationStructure)).BeginInit();
            this.SuspendLayout();
            // 
            // tlpOrganizationStructure
            // 
            this.tlpOrganizationStructure.ColumnCount = 1;
            this.tlpOrganizationStructure.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpOrganizationStructure.Controls.Add(this.dgvOrganizationStructure, 0, 0);
            this.tlpOrganizationStructure.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpOrganizationStructure.Location = new System.Drawing.Point(0, 0);
            this.tlpOrganizationStructure.Name = "tlpOrganizationStructure";
            this.tlpOrganizationStructure.RowCount = 1;
            this.tlpOrganizationStructure.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpOrganizationStructure.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpOrganizationStructure.Size = new System.Drawing.Size(800, 450);
            this.tlpOrganizationStructure.TabIndex = 0;
            // 
            // dgvOrganizationStructure
            // 
            this.dgvOrganizationStructure.AllowUserToAddRows = false;
            this.dgvOrganizationStructure.AllowUserToDeleteRows = false;
            this.dgvOrganizationStructure.AutoGenerateColumns = false;
            this.dgvOrganizationStructure.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvOrganizationStructure.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrganizationStructure.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colDepartamentName,
            this.colDepartamentManager,
            this.colLocalization});
            this.dgvOrganizationStructure.DataSource = this.bsOrganizationStructure;
            this.dgvOrganizationStructure.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvOrganizationStructure.GridColor = System.Drawing.SystemColors.Control;
            this.dgvOrganizationStructure.Location = new System.Drawing.Point(3, 3);
            this.dgvOrganizationStructure.Name = "dgvOrganizationStructure";
            this.dgvOrganizationStructure.ReadOnly = true;
            this.dgvOrganizationStructure.RowHeadersVisible = false;
            this.dgvOrganizationStructure.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvOrganizationStructure.Size = new System.Drawing.Size(794, 444);
            this.dgvOrganizationStructure.TabIndex = 0;
            // 
            // bsOrganizationStructure
            // 
            this.bsOrganizationStructure.DataSource = typeof(SystemHR.DataAccessLayer.ViewModels.OrganizationStructureViewModel);
            // 
            // colDepartamentName
            // 
            this.colDepartamentName.DataPropertyName = "DepartamentName";
            this.colDepartamentName.HeaderText = "Nazwa działu";
            this.colDepartamentName.Name = "colDepartamentName";
            this.colDepartamentName.ReadOnly = true;
            this.colDepartamentName.Width = 200;
            // 
            // colDepartamentManager
            // 
            this.colDepartamentManager.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colDepartamentManager.DataPropertyName = "DepartamentManager";
            this.colDepartamentManager.HeaderText = "Kierownik działu";
            this.colDepartamentManager.Name = "colDepartamentManager";
            this.colDepartamentManager.ReadOnly = true;
            // 
            // colLocalization
            // 
            this.colLocalization.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colLocalization.DataPropertyName = "Localization";
            this.colLocalization.HeaderText = "Lokalizacja";
            this.colLocalization.Name = "colLocalization";
            this.colLocalization.ReadOnly = true;
            // 
            // OrganizationStructureForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tlpOrganizationStructure);
            this.Name = "OrganizationStructureForm";
            this.ShowIcon = false;
            this.Text = "Struktura organizacyjna";
            this.tlpOrganizationStructure.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrganizationStructure)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsOrganizationStructure)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpOrganizationStructure;
        private System.Windows.Forms.DataGridView dgvOrganizationStructure;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDepartamentName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDepartamentManager;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLocalization;
        private System.Windows.Forms.BindingSource bsOrganizationStructure;
    }
}