﻿namespace SystemHR.UserInterface.Forms.Salaries
{
    partial class SalariesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tlpSalaries = new System.Windows.Forms.TableLayoutPanel();
            this.pSalariesButtons = new System.Windows.Forms.Panel();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.pSalaries = new System.Windows.Forms.Panel();
            this.txtPosition = new System.Windows.Forms.TextBox();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.txtPESEL = new System.Windows.Forms.TextBox();
            this.txtDateBitrth = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtGender = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblPosition = new System.Windows.Forms.Label();
            this.lblPESEL = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblDateBirth = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.dgvSalaries = new System.Windows.Forms.DataGridView();
            this.colAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCurrency = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTypeRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDateFrom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDateTo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsSalaries = new System.Windows.Forms.BindingSource(this.components);
            this.tlpSalaries.SuspendLayout();
            this.pSalariesButtons.SuspendLayout();
            this.pSalaries.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSalaries)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsSalaries)).BeginInit();
            this.SuspendLayout();
            // 
            // tlpSalaries
            // 
            this.tlpSalaries.ColumnCount = 1;
            this.tlpSalaries.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpSalaries.Controls.Add(this.pSalariesButtons, 0, 0);
            this.tlpSalaries.Controls.Add(this.pSalaries, 0, 1);
            this.tlpSalaries.Controls.Add(this.dgvSalaries, 0, 2);
            this.tlpSalaries.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSalaries.Location = new System.Drawing.Point(0, 0);
            this.tlpSalaries.Name = "tlpSalaries";
            this.tlpSalaries.RowCount = 3;
            this.tlpSalaries.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tlpSalaries.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tlpSalaries.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpSalaries.Size = new System.Drawing.Size(1015, 450);
            this.tlpSalaries.TabIndex = 0;
            // 
            // pSalariesButtons
            // 
            this.pSalariesButtons.Controls.Add(this.btnNext);
            this.pSalariesButtons.Controls.Add(this.btnPrevious);
            this.pSalariesButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pSalariesButtons.Location = new System.Drawing.Point(3, 3);
            this.pSalariesButtons.Name = "pSalariesButtons";
            this.pSalariesButtons.Size = new System.Drawing.Size(1009, 45);
            this.pSalariesButtons.TabIndex = 0;
            // 
            // btnNext
            // 
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnNext.Location = new System.Drawing.Point(154, 9);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(139, 26);
            this.btnNext.TabIndex = 1;
            this.btnNext.Text = "Następny";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnPrevious.Location = new System.Drawing.Point(9, 9);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(139, 26);
            this.btnPrevious.TabIndex = 0;
            this.btnPrevious.Text = "Poprzedni";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // pSalaries
            // 
            this.pSalaries.Controls.Add(this.txtPosition);
            this.pSalaries.Controls.Add(this.txtStatus);
            this.pSalaries.Controls.Add(this.txtPESEL);
            this.pSalaries.Controls.Add(this.txtDateBitrth);
            this.pSalaries.Controls.Add(this.txtFirstName);
            this.pSalaries.Controls.Add(this.txtGender);
            this.pSalaries.Controls.Add(this.txtLastName);
            this.pSalaries.Controls.Add(this.lblPosition);
            this.pSalaries.Controls.Add(this.lblPESEL);
            this.pSalaries.Controls.Add(this.lblStatus);
            this.pSalaries.Controls.Add(this.lblDateBirth);
            this.pSalaries.Controls.Add(this.lblFirstName);
            this.pSalaries.Controls.Add(this.lblGender);
            this.pSalaries.Controls.Add(this.lblLastName);
            this.pSalaries.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pSalaries.Location = new System.Drawing.Point(3, 54);
            this.pSalaries.Name = "pSalaries";
            this.pSalaries.Size = new System.Drawing.Size(1009, 94);
            this.pSalaries.TabIndex = 1;
            // 
            // txtPosition
            // 
            this.txtPosition.Location = new System.Drawing.Point(851, 64);
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.Size = new System.Drawing.Size(149, 20);
            this.txtPosition.TabIndex = 13;
            // 
            // txtStatus
            // 
            this.txtStatus.Location = new System.Drawing.Point(851, 22);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(149, 20);
            this.txtStatus.TabIndex = 12;
            // 
            // txtPESEL
            // 
            this.txtPESEL.Location = new System.Drawing.Point(582, 61);
            this.txtPESEL.Name = "txtPESEL";
            this.txtPESEL.Size = new System.Drawing.Size(149, 20);
            this.txtPESEL.TabIndex = 11;
            // 
            // txtDateBitrth
            // 
            this.txtDateBitrth.Location = new System.Drawing.Point(364, 61);
            this.txtDateBitrth.Name = "txtDateBitrth";
            this.txtDateBitrth.Size = new System.Drawing.Size(149, 20);
            this.txtDateBitrth.TabIndex = 10;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(364, 19);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(149, 20);
            this.txtFirstName.TabIndex = 9;
            // 
            // txtGender
            // 
            this.txtGender.Location = new System.Drawing.Point(92, 58);
            this.txtGender.Name = "txtGender";
            this.txtGender.Size = new System.Drawing.Size(149, 20);
            this.txtGender.TabIndex = 8;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(92, 16);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(149, 20);
            this.txtLastName.TabIndex = 7;
            // 
            // lblPosition
            // 
            this.lblPosition.AutoSize = true;
            this.lblPosition.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPosition.Location = new System.Drawing.Point(754, 64);
            this.lblPosition.Name = "lblPosition";
            this.lblPosition.Size = new System.Drawing.Size(73, 17);
            this.lblPosition.TabIndex = 6;
            this.lblPosition.Text = "Stanowisko";
            // 
            // lblPESEL
            // 
            this.lblPESEL.AutoSize = true;
            this.lblPESEL.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPESEL.Location = new System.Drawing.Point(534, 64);
            this.lblPESEL.Name = "lblPESEL";
            this.lblPESEL.Size = new System.Drawing.Size(42, 17);
            this.lblPESEL.TabIndex = 5;
            this.lblPESEL.Text = "PESEL";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblStatus.Location = new System.Drawing.Point(754, 22);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(43, 17);
            this.lblStatus.TabIndex = 4;
            this.lblStatus.Text = "Status";
            // 
            // lblDateBirth
            // 
            this.lblDateBirth.AutoSize = true;
            this.lblDateBirth.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblDateBirth.Location = new System.Drawing.Point(261, 61);
            this.lblDateBirth.Name = "lblDateBirth";
            this.lblDateBirth.Size = new System.Drawing.Size(97, 17);
            this.lblDateBirth.TabIndex = 3;
            this.lblDateBirth.Text = "Data urodzenia";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblFirstName.Location = new System.Drawing.Point(261, 19);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(32, 17);
            this.lblFirstName.TabIndex = 2;
            this.lblFirstName.Text = "Imię";
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblGender.Location = new System.Drawing.Point(22, 58);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(31, 17);
            this.lblGender.TabIndex = 1;
            this.lblGender.Text = "Płeć";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblLastName.Location = new System.Drawing.Point(22, 16);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(63, 17);
            this.lblLastName.TabIndex = 0;
            this.lblLastName.Text = "Nazwisko";
            // 
            // dgvSalaries
            // 
            this.dgvSalaries.AllowUserToAddRows = false;
            this.dgvSalaries.AllowUserToDeleteRows = false;
            this.dgvSalaries.AutoGenerateColumns = false;
            this.dgvSalaries.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvSalaries.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSalaries.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colAmount,
            this.colCurrency,
            this.colTypeRate,
            this.colDateFrom,
            this.colDateTo});
            this.dgvSalaries.DataSource = this.bsSalaries;
            this.dgvSalaries.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSalaries.GridColor = System.Drawing.SystemColors.Control;
            this.dgvSalaries.Location = new System.Drawing.Point(3, 154);
            this.dgvSalaries.Name = "dgvSalaries";
            this.dgvSalaries.ReadOnly = true;
            this.dgvSalaries.RowHeadersVisible = false;
            this.dgvSalaries.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSalaries.Size = new System.Drawing.Size(1009, 293);
            this.dgvSalaries.TabIndex = 2;
            // 
            // colAmount
            // 
            this.colAmount.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colAmount.DataPropertyName = "Amount";
            this.colAmount.HeaderText = "Kwota";
            this.colAmount.Name = "colAmount";
            this.colAmount.ReadOnly = true;
            // 
            // colCurrency
            // 
            this.colCurrency.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colCurrency.DataPropertyName = "Currency";
            this.colCurrency.HeaderText = "Waluta";
            this.colCurrency.Name = "colCurrency";
            this.colCurrency.ReadOnly = true;
            // 
            // colTypeRate
            // 
            this.colTypeRate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTypeRate.DataPropertyName = "TypeRate";
            this.colTypeRate.HeaderText = "Rodzaj stawki";
            this.colTypeRate.Name = "colTypeRate";
            this.colTypeRate.ReadOnly = true;
            // 
            // colDateFrom
            // 
            this.colDateFrom.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colDateFrom.DataPropertyName = "DateFrom";
            this.colDateFrom.HeaderText = "Data od";
            this.colDateFrom.Name = "colDateFrom";
            this.colDateFrom.ReadOnly = true;
            // 
            // colDateTo
            // 
            this.colDateTo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colDateTo.DataPropertyName = "DateTo";
            this.colDateTo.HeaderText = "Data do";
            this.colDateTo.Name = "colDateTo";
            this.colDateTo.ReadOnly = true;
            // 
            // bsSalaries
            // 
            this.bsSalaries.DataSource = typeof(SystemHR.DataAccessLayer.ViewModels.SalariesViewModel);
            // 
            // SalariesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1015, 450);
            this.Controls.Add(this.tlpSalaries);
            this.Name = "SalariesForm";
            this.ShowIcon = false;
            this.Text = "Wynagrodzenia";
            this.tlpSalaries.ResumeLayout(false);
            this.pSalariesButtons.ResumeLayout(false);
            this.pSalaries.ResumeLayout(false);
            this.pSalaries.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSalaries)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsSalaries)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpSalaries;
        private System.Windows.Forms.Panel pSalariesButtons;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Panel pSalaries;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.TextBox txtGender;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblPosition;
        private System.Windows.Forms.Label lblPESEL;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblDateBirth;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtPosition;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.TextBox txtPESEL;
        private System.Windows.Forms.TextBox txtDateBitrth;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.DataGridView dgvSalaries;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCurrency;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTypeRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDateFrom;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDateTo;
        private System.Windows.Forms.BindingSource bsSalaries;
    }
}