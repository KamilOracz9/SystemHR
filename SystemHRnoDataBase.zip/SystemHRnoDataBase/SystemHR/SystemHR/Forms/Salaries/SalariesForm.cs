﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.ViewModels;

namespace SystemHR.UserInterface.Forms.Salaries
{
    public partial class SalariesForm : Form
    {
        #region fields
        public static bool tabIsOpen = false;
        private SalariesViewModel salaries;
        private DefaultEmployeeData defaultEmployeeDatas;
        #endregion
        #region constructors
        public SalariesForm()
        {
            InitializeComponent();
            salaries = GetFakeSalaries();
            defaultEmployeeDatas = GetFakeDefaultEmployeeData();
            PrepareSalariesData();
            PrepareDefaultEmployeeDataData();
        }
        #endregion
        #region private methods
        private void PrepareSalariesData()
        {
            bsSalaries.DataSource = salaries;
            dgvSalaries.DataSource = bsSalaries;
        }

        private SalariesViewModel GetFakeSalaries()
        {
            SalariesViewModel salaries = new SalariesViewModel
            {
                Amount = 10000,
                Currency = "Złoty",
                TypeRate = "Miesięczna",
                DateFrom = new DateTime(2000 - 06 - 26),
                DateTo = new DateTime(2010 - 06 - 26)
            };
            return salaries;
        }
        private void PrepareDefaultEmployeeDataData()
        {
            txtLastName.Text = defaultEmployeeDatas.FirstName;
            txtFirstName.Text = defaultEmployeeDatas.FirstName;
            txtGender.Text = defaultEmployeeDatas.Gender;
            txtDateBitrth.Text = defaultEmployeeDatas.DateBirth.ToString();
            txtPESEL.Text = defaultEmployeeDatas.PESEL;
            txtPosition.Text = defaultEmployeeDatas.Position;
            txtStatus.Text = defaultEmployeeDatas.Status;
        }

        private DefaultEmployeeData GetFakeDefaultEmployeeData()
        {
            DefaultEmployeeData defaultEmployeeData = new DefaultEmployeeData()
            {
                LastName = "Stonoga",
                FirstName = "Zbigniew",
                Gender = "Mężczyzna",
                DateBirth = new DateTime(1980 - 04 - 16),
                PESEL = "20582794820",
                Position = "Kierownik",
                Status = "Wprowadzony",
                Id = 1
            };
            return defaultEmployeeData;
        }
        #endregion
        #region events
        private void btnPrevious_Click(object sender, EventArgs e)
        {

        }

        private void btnNext_Click(object sender, EventArgs e)
        {

        }
        #endregion
    }
}
