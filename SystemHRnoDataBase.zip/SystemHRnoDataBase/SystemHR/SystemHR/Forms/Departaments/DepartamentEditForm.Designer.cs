﻿namespace SystemHR.UserInterface.Forms.Departaments
{
    partial class DepartamentEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblDepartament = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblManager = new System.Windows.Forms.Label();
            this.lblLocation = new System.Windows.Forms.Label();
            this.lblParentDepartament = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.cbManager = new System.Windows.Forms.ComboBox();
            this.txtLocation = new System.Windows.Forms.TextBox();
            this.cbParentDepartament = new System.Windows.Forms.ComboBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.bsManager = new System.Windows.Forms.BindingSource(this.components);
            this.bsParentDepartament = new System.Windows.Forms.BindingSource(this.components);
            this.epName = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.bsManager)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsParentDepartament)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.epName)).BeginInit();
            this.SuspendLayout();
            // 
            // lblDepartament
            // 
            this.lblDepartament.AutoSize = true;
            this.lblDepartament.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblDepartament.Location = new System.Drawing.Point(37, 34);
            this.lblDepartament.Name = "lblDepartament";
            this.lblDepartament.Size = new System.Drawing.Size(60, 30);
            this.lblDepartament.TabIndex = 1;
            this.lblDepartament.Text = "Dział";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblName.Location = new System.Drawing.Point(42, 86);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(47, 17);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "Nazwa";
            // 
            // lblManager
            // 
            this.lblManager.AutoSize = true;
            this.lblManager.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblManager.Location = new System.Drawing.Point(42, 137);
            this.lblManager.Name = "lblManager";
            this.lblManager.Size = new System.Drawing.Size(102, 17);
            this.lblManager.TabIndex = 3;
            this.lblManager.Text = "Kierownik działu";
            // 
            // lblLocation
            // 
            this.lblLocation.AutoSize = true;
            this.lblLocation.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblLocation.Location = new System.Drawing.Point(42, 187);
            this.lblLocation.Name = "lblLocation";
            this.lblLocation.Size = new System.Drawing.Size(70, 17);
            this.lblLocation.TabIndex = 4;
            this.lblLocation.Text = "Lokalizacja";
            // 
            // lblParentDepartament
            // 
            this.lblParentDepartament.AutoSize = true;
            this.lblParentDepartament.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblParentDepartament.Location = new System.Drawing.Point(42, 238);
            this.lblParentDepartament.Name = "lblParentDepartament";
            this.lblParentDepartament.Size = new System.Drawing.Size(101, 17);
            this.lblParentDepartament.TabIndex = 5;
            this.lblParentDepartament.Text = "Dział nadrzędny";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(187, 86);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(178, 20);
            this.txtName.TabIndex = 6;
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // cbManager
            // 
            this.cbManager.FormattingEnabled = true;
            this.cbManager.Location = new System.Drawing.Point(187, 137);
            this.cbManager.Name = "cbManager";
            this.cbManager.Size = new System.Drawing.Size(180, 21);
            this.cbManager.TabIndex = 12;
            // 
            // txtLocation
            // 
            this.txtLocation.Location = new System.Drawing.Point(187, 184);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Size = new System.Drawing.Size(178, 20);
            this.txtLocation.TabIndex = 13;
            // 
            // cbParentDepartament
            // 
            this.cbParentDepartament.FormattingEnabled = true;
            this.cbParentDepartament.Location = new System.Drawing.Point(187, 238);
            this.cbParentDepartament.Name = "cbParentDepartament";
            this.cbParentDepartament.Size = new System.Drawing.Size(178, 21);
            this.cbParentDepartament.TabIndex = 14;
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnCancel.Location = new System.Drawing.Point(240, 291);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(127, 48);
            this.btnCancel.TabIndex = 16;
            this.btnCancel.Text = "Anuluj";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnSave.Location = new System.Drawing.Point(107, 291);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(127, 48);
            this.btnSave.TabIndex = 15;
            this.btnSave.Text = "Zapisz";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // epName
            // 
            this.epName.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.epName.ContainerControl = this;
            // 
            // DepartamentEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 351);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.cbParentDepartament);
            this.Controls.Add(this.txtLocation);
            this.Controls.Add(this.cbManager);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblParentDepartament);
            this.Controls.Add(this.lblLocation);
            this.Controls.Add(this.lblManager);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblDepartament);
            this.Name = "DepartamentEditForm";
            this.Text = "DepartamentEditForm";
            ((System.ComponentModel.ISupportInitialize)(this.bsManager)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsParentDepartament)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.epName)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDepartament;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblManager;
        private System.Windows.Forms.Label lblLocation;
        private System.Windows.Forms.Label lblParentDepartament;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.ComboBox cbManager;
        private System.Windows.Forms.TextBox txtLocation;
        private System.Windows.Forms.ComboBox cbParentDepartament;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.BindingSource bsManager;
        private System.Windows.Forms.BindingSource bsParentDepartament;
        private System.Windows.Forms.ErrorProvider epName;
    }
}