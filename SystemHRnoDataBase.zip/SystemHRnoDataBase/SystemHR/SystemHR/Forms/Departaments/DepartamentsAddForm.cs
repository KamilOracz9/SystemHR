﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Classes;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Models.Dictionaries;
using SystemHR.UserInterface.Forms.Base;
using SystemHR.UserInterface.Helpers;

namespace SystemHR.UserInterface.Forms.Departaments
{
    public partial class DepartamentsAddForm : BaseForm
    {
        #region fields
        public EventHandler ReloadDepartaments;
        #endregion
        #region construktors
        public DepartamentsAddForm()
        {
            InitializeComponent();
            InitializeData();
            ValidateData();
        }
        #endregion
        #region private methods
        private void ValidateData()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                epName.SetError(txtName, "Pole Nazwa jest wymagane");
            }
            else epName.Clear();
        }

        private void InitializeData()
        {
            IList<Employee> managers = new List<Employee>()
            {
                new Employee("Stonoga","Zbigniew",3),
                new Employee(string.Empty,string.Empty,4)
            };
            bsManager.DataSource = managers;
            cbManager.Text = string.Empty;
            IList<Departament> departaments = new List<Departament>()
            {
                new Departament("Produkcja"),
                new Departament(string.Empty)
            };
            bsParentDepartament.DataSource = departaments;
            cbParentDepartament.Text = string.Empty;
        }
        private bool ValidationForm()
        {
            StringBuilder sbErrorMessage = new StringBuilder();
            string nameErrorMessage = epName.GetError(txtName);
            if (nameErrorMessage.Length > 0)
            {
                sbErrorMessage.Append(nameErrorMessage);
                MessageBox.Show(
                    sbErrorMessage.ToString(),
                    "Dodawanie Działu",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        #endregion
        #region events
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidationForm())
            {
                DepartamentModel departament = new DepartamentModel()
                {
                    Name = txtName.Text,
                    Manager = (Employee)cbManager.SelectedItem,
                    Location = txtLocation.Text,
                    ParentDepartament = (Departament)cbParentDepartament.SelectedItem
                };
                ReloadDepartaments?.Invoke(btnSave, new DepartamentEventArgs(departament));
                Close();
            }

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            ValidateData();
        }
        #endregion
    }
}
