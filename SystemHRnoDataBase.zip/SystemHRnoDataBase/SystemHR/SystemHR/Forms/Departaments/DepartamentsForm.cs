﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Classes;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Models.Dictionaries;
using SystemHR.DataAccessLayer.ViewModels;
using SystemHR.UserInterface.Helpers;

namespace SystemHR.UserInterface.Forms.Departaments
{
    public partial class DepartamentsForm : Form
    {
        #region fields
        public static bool tabIsOpen = false;
        private IList<DepartamentViewModel> fakeDepartament;
        #endregion
        #region constructors
        public DepartamentsForm()
        {
            InitializeComponent();
            fakeDepartament = GetFakeDepartaments();
            PrepareDepartamentsData();
        }
        #endregion
        #region private methods
        private void PrepareDepartamentsData()
        {
            bsDepartaments.DataSource = new BindingList<DepartamentViewModel>(fakeDepartament);
            dgvDepartaments.DataSource = bsDepartaments;
        }

        private IList<DepartamentViewModel> GetFakeDepartaments()
        {
            IList<DepartamentModel> fakeDepartamentModel = new List<DepartamentModel>()
            {
                new DepartamentModel()
                {
                    Name = "Produkcja",
                    Manager = new Employee("Stonoga","Zbigniew",2),
                    Location = "Pierwsze piętro",
                    ParentDepartament = new Departament("Administracja")
                }
            };
            return MappingHelper.MapDepartamentModelToDepartamentViewModel(fakeDepartamentModel);
        }
        #endregion
        #region events
        private void btnCreate_Click(object sender, EventArgs e)
        {
            DepartamentsAddForm frm = new DepartamentsAddForm();
            frm.ReloadDepartaments += (s, ea) =>
            {
                DepartamentEventArgs eventArgs = ea as DepartamentEventArgs;
                if (eventArgs != null)
                {
                    DepartamentViewModel departament = MappingHelper.MapDepartamentModelToDepartamentViewModel(eventArgs.departament);
                    bsDepartaments.Add(departament);
                    dgvDepartaments.ClearSelection();
                    dgvDepartaments.Rows[dgvDepartaments.Rows.Count - 1].Selected = true;
                }
            };
            frm.ShowDialog();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            int departamentId = Convert.ToInt32(dgvDepartaments.CurrentRow.Cells["colId"].Value);
            int selectedRowIndex = dgvDepartaments.CurrentRow.Index;
            DepartamentViewModel departament = fakeDepartament.Where(x => x.Id == departamentId).FirstOrDefault();
            if (departament != null)
            {
                bsDepartaments.Remove(departament);
                if (dgvDepartaments.Rows.Count > 0)
                {
                    dgvDepartaments.ClearSelection();
                    dgvDepartaments.Rows[dgvDepartaments.Rows.Count - 1].Selected = true;
                }
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            dgvDepartaments.Refresh();
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            int departamentId = Convert.ToInt32(dgvDepartaments.CurrentRow.Cells["colId"].Value);
            int selectedRowIndex = dgvDepartaments.CurrentRow.Index;
            DepartamentEditForm frm = new DepartamentEditForm(departamentId);
            frm.ReloadDepartaments += (s, ea) =>
            {
                DepartamentEventArgs eventArgs = ea as DepartamentEventArgs;
                if (eventArgs != null)
                {
                    DepartamentViewModel departament = MappingHelper.MapDepartamentModelToDepartamentViewModel(eventArgs.departament);
                    bsDepartaments[selectedRowIndex] = departament;
                }
            };
            frm.ShowDialog();
        }
        #endregion
    }
}
