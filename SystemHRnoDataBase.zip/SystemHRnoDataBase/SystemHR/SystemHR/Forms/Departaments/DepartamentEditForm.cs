﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Classes;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Models.Dictionaries;
using SystemHR.DataAccessLayer.ViewModels;
using SystemHR.UserInterface.Forms.Base;
using SystemHR.UserInterface.Helpers;

namespace SystemHR.UserInterface.Forms.Departaments
{
    public partial class DepartamentEditForm : BaseForm
    {
        #region fields
        private DepartamentModel departament;
        public EventHandler ReloadDepartaments;
        #endregion
        #region constructores
        public DepartamentEditForm(int departamentId)
        {
            InitializeComponent();
            InitializeData();
            departament = (DepartamentModel)GetFakeDepartaments(departamentId);
            PreapreDepartamentsData(departament);
            ValidateData();
        }
        #endregion
        #region private methods
        private void ValidateData()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                epName.SetError(txtName, "Pole nazwa jest wymagane");
            }
            else epName.Clear();
        }

        private void InitializeData()
        {
            IList<Employee> managers = new List<Employee>()
            {
                new Employee("Stonoga","Zbigniew",3),
                new Employee(string.Empty,string.Empty,4)
            };
            bsManager.DataSource = managers;
            cbManager.Text = string.Empty;
            IList<Departament> departaments = new List<Departament>()
            {
                new Departament("Produkcja"),
                new Departament(string.Empty)
            };
            bsParentDepartament.DataSource = departaments;
            cbParentDepartament.Text = string.Empty;
        }

        private void PreapreDepartamentsData(DepartamentModel departament)
        {
            txtName.Text = departament.Name;
            cbManager.Text = departament.Manager.LastName + departament.Manager.FirstName;
            txtLocation.Text = departament.Location;
            cbParentDepartament.Text = departament.ParentDepartament.Value;
        }
        private DepartamentModel GetFakeDepartaments(int departamentId)
        {
            IList<DepartamentModel> fakeDepartamentsModel = new List<DepartamentModel>()
            {
                new DepartamentModel()
                {
                    Name = "Produkcja",
                    Manager = new Employee("Stonoga","Zbigniew",2),
                    Location = "Pierwsze piętro",
                    ParentDepartament = new Departament("Administracja")
                }
            };
            DepartamentModel fakeDepartamentModel = fakeDepartamentsModel.Where(x => x.Id == departamentId).FirstOrDefault();
            return fakeDepartamentModel;
        }
        #endregion
        #region events
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidationForm())
            {
                departament.Name = txtName.Text;
                departament.Manager = (Employee)cbManager.SelectedItem;
                departament.Location = txtLocation.Text;
                departament.ParentDepartament = (Departament)cbParentDepartament.SelectedItem;
                ReloadDepartaments?.Invoke(btnSave, new DepartamentEventArgs(departament));
                Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            ValidateData();
        }
        private bool ValidationForm()
        {
            StringBuilder sbErrorMessage = new StringBuilder();
            string nameErrorMessage = epName.GetError(txtName);
            if (nameErrorMessage.Length > 0)
            {
                sbErrorMessage.Append(nameErrorMessage);
                MessageBox.Show(nameErrorMessage.ToString(),
                    "Modyfikowanie działu",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        #endregion
    }
}
