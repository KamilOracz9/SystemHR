﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Classes;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Models.Dictionaries;
using SystemHR.DataAccessLayer.ViewModels;
using SystemHR.UserInterface.Extensions;
using SystemHR.UserInterface.Forms.Base;
using SystemHR.UserInterface.Helpers;

namespace SystemHR.UserInterface.Forms.Employees
{
    public partial class EmployeeEditForm : BaseForm
    {

        #region fields
        private EmployeeModel employee;
        public EventHandler ReloadEmployees;
        #endregion
        #region constructor
        public EmployeeEditForm(int employeeId)
        {
            InitializeComponent();
            InitializeData();
            employee = GetFakeEmployees(employeeId);
            PrepareEmployeesData(employee);
            ValidateControls();
        }

        #endregion
        #region private methods
        private void PrepareEmployeesData(EmployeeModel employee)
        {
            txtLastName.Text = employee.LastName;
            txtFirstName.Text = employee.FirstName;
            cbGender.Text = employee.Gender != null ? employee.Gender.Value : null;
            dtpDateBirth.SetDateTimePickerValue(employee.DateBirth);
            txtPESEL.Text = employee.PESEL;
            txtPhoneNumber.Text = employee.PhoneNumber;
            txtEmailAdress.Text = employee.EmailAdress;
            txtIdentityNumber.Text = employee.IdentityCardNumber;
            dtpIssueDateIdentityCard.SetDateTimePickerValue(employee.IssueDataIdentityCard);
            dtpExpirationDateIdentityCard.SetDateTimePickerValue(employee.ExpirationDataIdentityTime);
            txtPassportNumber.Text = employee.PassportNumber;
            dtpIssueDatePassport.SetDateTimePickerValue(employee.IssueDataPassport);
            dtpExpirationDateIdentityCard.SetDateTimePickerValue(employee.ExpirationDataPassport);

            lblEmployee.Text = $"{employee.FirstName} {employee.LastName} ({employee.Code.ToString().PadLeft(4, '0')}) - {employee.Status.ToString()}";
        }

        private EmployeeModel GetFakeEmployees(int employeeId)
        {
            IList<EmployeeModel> fakeEmployeesModel = new List<EmployeeModel>()
                {
                    new EmployeeModel()
                    {
                        Id = 1,
                        LastName = "Przykładowy",
                        FirstName = "Użytkownik",
                        Code = 1,
                        Gender = new GenderModel("Mężczyzna"),
                        DateBirth = new DateTime(1996,05,06),
                        PESEL = "96050648105",
                        PhoneNumber = "581950381",
                        EmailAdress = "PrzykładowyUżytkownik@gmail.com",
                        IdentityCardNumber = "WNC193752",
                        IssueDataIdentityCard = new DateTime(2010,05,10),
                        ExpirationDataIdentityTime = new DateTime(2020,05,10),
                        PassportNumber = "RN0371950",
                        IssueDataPassport = new DateTime(2011,06,09),
                        ExpirationDataPassport = new DateTime(2021,06,09),
                        Status=new StatusModel("Wprowadzony")
                    }
                };
            EmployeeModel fakeEmployeeModel = fakeEmployeesModel.Where(x => x.Id == employeeId).FirstOrDefault();
            return fakeEmployeeModel;
        }

        private void ValidateControls()
        {
            if (string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                epLastName.SetError(txtLastName, "Pole nazwisko jest wymagane!");
            }
            else
            {
                epLastName.Clear();
            }
            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                epFirstName.SetError(txtFirstName, "Pole imię jest wymagane!");
            }
            else
            {
                epFirstName.Clear();
            }
            if (!string.IsNullOrWhiteSpace(txtPESEL.Text) && !ValidatorHelper.IsValidPESEL(txtPESEL.Text))
            {
                epPESEL.SetError(txtPESEL, "PESEL jest nieprawidłowy");
            }
            else
            {
                epPESEL.Clear();
            }
        }

        private void InitializeData()
        {
            IList<GenderModel> genders = new List<GenderModel>()
            {
                new GenderModel("Kobieta"),
                new GenderModel("Mężczyzna"),
                new GenderModel(string.Empty)
            };
            bsGender.DataSource = genders;
            cbGender.Text = string.Empty;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateForm())
            {
                employee.LastName = txtLastName.Text;
                employee.FirstName = txtFirstName.Text;
                employee.Gender = new GenderModel(cbGender.Text);
                employee.DateBirth = dtpDateBirth.Value;
                employee.PESEL = txtPESEL.Text;
                employee.PhoneNumber = txtPhoneNumber.Text;
                employee.EmailAdress = txtEmailAdress.Text;
                employee.IdentityCardNumber = txtIdentityNumber.Text;
                employee.IssueDataIdentityCard = dtpIssueDateIdentityCard.Value;
                employee.ExpirationDataIdentityTime = dtpExpirationDateIdentityCard.Value;
                employee.PassportNumber = txtPassportNumber.Text;
                employee.IssueDataPassport = dtpIssueDatePassport.Value;
                employee.ExpirationDataPassport = dtpExpirationDataPassport.Value;
                //employee = ModifyEmployee(employee);
                ReloadEmployees?.Invoke(btnSave, new EmployeeEventArgs(employee));

                Close();
            }

        }

        private bool ValidateForm()
        {
            StringBuilder sbErrorMessage = new StringBuilder();
            string lastNameErrorMessage = epLastName.GetError(txtLastName);
            if (!string.IsNullOrEmpty(lastNameErrorMessage))
            {
                sbErrorMessage.Append(lastNameErrorMessage);
            }
            string firstNameErrorMessage = epFirstName.GetError(txtFirstName);
            if (!string.IsNullOrEmpty(firstNameErrorMessage))
            {
                sbErrorMessage.Append(firstNameErrorMessage);
            }
            if (sbErrorMessage.Length > 0)
            {
                MessageBox.Show(
                    sbErrorMessage.ToString(),
                    "Dodawanie pracownika",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
            string peselWarningMessage = epPESEL.GetError(txtPESEL);
            if (!string.IsNullOrEmpty(peselWarningMessage))
            {
                DialogResult answer =
                    MessageBox.Show(
                        peselWarningMessage + Environment.NewLine + "PESEL jest nieprawidłowy, czy mimo to chcesz dodać nowego pracownika?",
                        "Dodawanie pracownika",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Warning);
                if (answer == DialogResult.No)
                {
                    return false;
                }
            }
            return true;
        }
        #endregion
        #region events
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dtp_ValueChanged(object sender, EventArgs e)
        {
            DateTimePicker dtp = sender as DateTimePicker;
            dtp.DateTimePickerValueChanged();
        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {
            ValidateControls();
        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {
            ValidateControls();
        }

        private void txtPESEL_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtPESEL_Validated(object sender, EventArgs e)
        {
            string pesel = txtPESEL.Text;
            if (!string.IsNullOrWhiteSpace(pesel) && !ValidatorHelper.IsValidPESEL(pesel))
            {
                epPESEL.SetError(txtPESEL, "PESEL jest nieprawidłowy");
            }
            else
            {
                epPESEL.Clear();
            }
        }
        #endregion
    }
}
