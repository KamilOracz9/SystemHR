﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemHR.DataAccessLayer.Classes;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Models.Dictionaries;
using SystemHR.DataAccessLayer.ViewModels;
using SystemHR.UserInterface.Helpers;

namespace SystemHR.UserInterface.Forms.Employees
{
    public partial class EmployeesForm : Form
    {
        #region fields
        public static bool tabIsOpen = false;
        private static IList<EmployeeViewModel> fakeEmployees;

        #endregion
        #region constructor
        public EmployeesForm()
        {
            InitializeComponent();
            fakeEmployees = GetFakeEmployees();
            PrepareEmployeesData();
        }
        #endregion
        #region private methods
        private void PrepareEmployeesData()
        {
            var fakeEmployeesSorted = fakeEmployees.OrderBy(x => x.Code).ToList();
            bsEmployees.DataSource = new BindingList<EmployeeViewModel>(fakeEmployeesSorted);
            dgvEmployees.DataSource = bsEmployees;
        }

        private IList<EmployeeViewModel> GetFakeEmployees()
        {
            IList<EmployeeModel> fakeEmployeesModel = new List<EmployeeModel>()
            {
                new EmployeeModel()
                {
                    Id = 1,
                    LastName = "Przykładowy",
                    FirstName = "Użytkownik",
                    Code = 1,
                    Gender = new GenderModel("Mężczyzna"),
                    DateBirth = new DateTime(1996,05,06),
                    PESEL = "96050648105",
                    PhoneNumber = "581950381",
                    EmailAdress = "PrzykładowyUżytkownik@gmail.com",
                    IdentityCardNumber = "WNC193752",
                    IssueDataIdentityCard = new DateTime(2010,05,10),
                    ExpirationDataIdentityTime = new DateTime(2020,05,10),
                    PassportNumber = "RN0371950",
                    IssueDataPassport = new DateTime(2011,06,09),
                    ExpirationDataPassport = new DateTime(2021,06,09),
                    Status=new StatusModel("Wprowadzony")
                }
            };
            return MappingHelper.MapEmployeeModelToEmployeeViewModel(fakeEmployeesModel);
        }
        #endregion
        #region events
        private void btnCreate_Click(object sender, EventArgs e)
        {
            EmployeeAddForm frm = new EmployeeAddForm();
            frm.ReloadEmployees += (s, ea) =>
            {
                EmployeeEventArgs eventArgs = ea as EmployeeEventArgs;
                if (eventArgs != null)
                {
                    EmployeeViewModel employee = MappingHelper.MapEmployeeModelToEmployeeViewModel(eventArgs.employee);
                    bsEmployees.Add(employee);
                    dgvEmployees.ClearSelection();
                    dgvEmployees.Rows[dgvEmployees.Rows.Count - 1].Selected = true;
                }
            };
            frm.ShowDialog();

        }
        private void btnModify_Click(object sender, EventArgs e)
        {
            int employeeId = Convert.ToInt32(dgvEmployees.CurrentRow.Cells["colId"].Value);
            int selectedRowIndex = dgvEmployees.CurrentRow.Index;
            EmployeeEditForm frm = new EmployeeEditForm(employeeId);
            frm.ReloadEmployees += (s, ea) =>
            {
                EmployeeEventArgs eventArgs = ea as EmployeeEventArgs;
                if (eventArgs != null)
                {
                    EmployeeViewModel employee = MappingHelper.MapEmployeeModelToEmployeeViewModel(eventArgs.employee);
                    bsEmployees[selectedRowIndex] = employee;
                }
            };
            frm.ShowDialog();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            int employeeId = Convert.ToInt32(dgvEmployees.CurrentRow.Cells["colId"].Value);
            int selectedRowIndex = dgvEmployees.CurrentRow.Index;
            //RemoveEmployee();
            EmployeeViewModel employee = fakeEmployees.Where(x => x.Id == employeeId).FirstOrDefault();
            if (employee != null)
            {
                bsEmployees.Remove(employee);
                if (dgvEmployees.Rows.Count > 0)
                {
                    dgvEmployees.ClearSelection();
                    dgvEmployees.Rows[dgvEmployees.Rows.Count - 1].Selected = true;
                }
            }
        }
        private void btnDismiss_Click(object sender, EventArgs e)
        {
            int employeeId = Convert.ToInt32(dgvEmployees.CurrentRow.Cells["colId"].Value);
            int selectedRowIndex = dgvEmployees.CurrentRow.Index;
            EmployeeViewModel employee = fakeEmployees.Where(x => x.Id == employeeId).FirstOrDefault();
            DialogResult answer =
                MessageBox.Show(
                    "Czy napewno chcesz zwolnić pracownika?",
                    "Zwalnianie pracownika",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                employee.Status = "Zwolniony";
                MessageBox.Show("Zwolniono pracownika");
            }
            dgvEmployees.Refresh();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            dgvEmployees.Refresh();
            MessageBox.Show("Załadowano ponownie listę pracowników");
        }
        #endregion
    }
}
