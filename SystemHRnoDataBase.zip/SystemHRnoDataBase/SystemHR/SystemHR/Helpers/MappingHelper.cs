﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using SystemHR.DataAccessLayer.Models;
using SystemHR.DataAccessLayer.Models.Dictionaries;
using SystemHR.DataAccessLayer.ViewModels;

namespace SystemHR.UserInterface.Helpers
{
    public class MappingHelper
    {
        #region employee
        public static EmployeeViewModel MapEmployeeModelToEmployeeViewModel(EmployeeModel employeeModel)
        {
            EmployeeViewModel employeeViewModel = new EmployeeViewModel();
            employeeViewModel.Id = employeeModel.Id;
            employeeViewModel.LastName = employeeModel.LastName;
            employeeViewModel.FirstName = employeeModel.FirstName;
            employeeViewModel.Code = employeeModel.Code.ToString();
            employeeViewModel.Position = string.Empty;
            employeeViewModel.Status = employeeModel.Status.ToString();
            return employeeViewModel;
        }

        public static IList<EmployeeViewModel> MapEmployeeModelToEmployeeViewModel
            (IList<EmployeeModel> employeesModels)
        {
            IList<EmployeeViewModel> fakeEmployeeViewModels = new List<EmployeeViewModel>();
            foreach (EmployeeModel employeesModel in employeesModels)
            {
                EmployeeViewModel employeeViewModel = new EmployeeViewModel();
                employeeViewModel.Id = employeesModel.Id;
                employeeViewModel.LastName = employeesModel.LastName;
                employeeViewModel.FirstName = employeesModel.FirstName;
                employeeViewModel.Code = employeesModel.Code.ToString();
                employeeViewModel.Position = string.Empty;
                employeeViewModel.Status = employeesModel.Status.ToString();

                fakeEmployeeViewModels.Add(employeeViewModel);
            }
            return fakeEmployeeViewModels;
        }
        #endregion
        #region contract
        public static ContractViewModel MapContractModelToContractViewModel(ContractModel contractModel)
        {
            ContractViewModel contractViewModel = new ContractViewModel();
            contractViewModel.Id = contractModel.Id;
            contractViewModel.LastName = contractModel.LastName;
            contractViewModel.FirstName = contractModel.FirstName;
            contractViewModel.Code = contractModel.Code.ToString();
            contractViewModel.TypeContract = contractModel.TypeContract;
            contractViewModel.DateFrom = contractModel.DateFrom;
            contractViewModel.DateTo = contractModel.DateTo;
            contractViewModel.ConclusionDate = contractModel.ConclusionDate;
            contractViewModel.TerminationWay = contractModel.TerminationWay.ToString() != null ? contractModel.TerminationWay.Value : null; 
            return contractViewModel;
        }
        public static IList<ContractViewModel>MapContractModelToContractViewModel
            (IList<ContractModel> contractsModel)
        {
            IList<ContractViewModel> fakeContractViewModes = new List<ContractViewModel>();
            foreach (ContractModel contractModel in contractsModel)
            {
                ContractViewModel contractViewModel = new ContractViewModel();
                contractViewModel.Id = contractModel.Id;
                contractViewModel.LastName = contractModel.LastName;
                contractViewModel.FirstName = contractModel.FirstName;
                contractViewModel.Code = contractModel.Code.ToString();
                contractViewModel.TypeContract = contractModel.TypeContract;
                contractViewModel.DateFrom = contractModel.DateFrom;
                contractViewModel.DateTo = contractModel.DateTo;
                contractViewModel.ConclusionDate = contractModel.ConclusionDate;
                contractViewModel.TerminationWay = contractModel.TerminationWay.ToString();

                fakeContractViewModes.Add(contractViewModel);
            }
            return fakeContractViewModes;
        }
        #endregion
        #region departaments
        public static DepartamentViewModel MapDepartamentModelToDepartamentViewModel(DepartamentModel departamentsModel)
        {
                DepartamentViewModel departamentViewModel = new DepartamentViewModel();
                departamentViewModel.Name = departamentsModel.Name;
                departamentViewModel.Manager = departamentsModel.Manager;
                departamentViewModel.Location = departamentsModel.Location;
                departamentViewModel.ParentDepartament = departamentsModel.ParentDepartament;
                return departamentViewModel;
        }
        public static IList<DepartamentViewModel> MapDepartamentModelToDepartamentViewModel
            (IList<DepartamentModel> departamentsModel)
        {
            IList<DepartamentViewModel> departamentViewModels = new List<DepartamentViewModel>();
            foreach (DepartamentModel departamentModel in departamentsModel)
            {
                DepartamentViewModel departamentViewModel = new DepartamentViewModel();
                departamentViewModel.Name = departamentModel.Name;
                departamentViewModel.Manager = departamentModel.Manager;
                departamentViewModel.Location = departamentModel.Location;
                departamentViewModel.ParentDepartament = departamentModel.ParentDepartament;

                departamentViewModels.Add(departamentViewModel);
            }
            return departamentViewModels;
        }
        #endregion
    }
}
