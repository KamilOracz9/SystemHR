﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using SystemHR.DataAccessLayer.Models;

namespace SystemHR.DataAccessLayer.Classes
{
    public class EmployeeEventArgs : EventArgs
    {
        public EmployeeModel employee { private set; get; }
        public EmployeeEventArgs(EmployeeModel employee)
        {
            this.employee = employee;
        }
    }
}
