﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SystemHR.DataAccessLayer.Models;

namespace SystemHR.DataAccessLayer.Classes
{
    public class DepartamentEventArgs : EventArgs
    {
        public DepartamentModel departament { private set; get; }

        public DepartamentEventArgs(DepartamentModel departament)
        {
            this.departament = departament;
        }

    }
}
