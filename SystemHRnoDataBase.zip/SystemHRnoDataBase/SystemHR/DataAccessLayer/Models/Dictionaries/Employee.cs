﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SystemHR.DataAccessLayer.Models.Dictionaries
{
    public class Employee
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public int Code { get; set; }

        public Employee(string lastName,string firstName,int code)
        {
            LastName = lastName;
            FirstName = firstName;
            Code = code;
        }
        public override string ToString()
        {
            return LastName + " " + FirstName;
        }
    }
}
