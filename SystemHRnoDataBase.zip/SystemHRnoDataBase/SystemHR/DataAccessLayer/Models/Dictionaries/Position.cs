﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SystemHR.DataAccessLayer.Models.Dictionaries
{
    public class Position
    {
        public string Value { get; set; }
        public Position(string value)
        {
            Value = value;
        }
    }
}
