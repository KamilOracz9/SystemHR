﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SystemHR.DataAccessLayer.Models.Dictionaries
{
    public class Departament
    {
        public string Value { get; set; }
        public Departament(string value)
        {
            Value = value;
        }
        public override string ToString()
        {
            return Value;
        }
    }
}
