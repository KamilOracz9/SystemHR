﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SystemHR.DataAccessLayer.Models;

namespace SystemHR.DataAccessLayer.ViewModels
{
    public class DefaultEmployeeData : EntityModel
    {
        public string LastName { get; set; }

        public string FirstName { get; set; }
        public string Gender { get; set; }
        public DateTime? DateBirth { get; set; }
        public string PESEL { get; set; }
        public string Position { get; set; }
        public string Status { get; set; }
    }
}
