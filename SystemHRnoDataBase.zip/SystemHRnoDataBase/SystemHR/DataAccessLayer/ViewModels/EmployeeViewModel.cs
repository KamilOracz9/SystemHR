﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SystemHR.DataAccessLayer.Models.Dictionaries;

namespace SystemHR.DataAccessLayer.ViewModels
{
    public class EmployeeViewModel
    {
        public int Id { get; set; }

        public string LastName { get; set; }
        public string FirstName { get; set; }

        private string code;
        public string Code 
        {
            get { return code.PadLeft(4, '0'); }
            set { code = value; }
        }

        public string Position { get; set; }

        public string Status { get; set; }
    }
}
